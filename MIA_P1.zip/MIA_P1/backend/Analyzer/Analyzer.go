package Analyzer

import (
	"MIA_P1/backend/FileSystem"
	"MIA_P1/backend/Management"
	"MIA_P1/backend/Rep"
	"MIA_P1/backend/User"
	"bufio" //Para leer la entrada del usuario
	"bytes"
	"flag"    //Para manejar parametros y opciones de comandos
	"fmt"     //imprimir
	"os"      // para ingre mediante consola
	"regexp"  //buscar y extraer parametros en la entrada
	"strings" //manipular cadenas de texto
)

// ER  mkdisk -size=3000 -unit=K -fit=BF -path=/home/cerezo/Disks/disk1.bin

//input := "mkdisk -size=3000 -unit=K -fit=BF -path=/home/cerezo/Disks/disk1.bin"
//mkdisk -size=200 -unit=M -path=C:/Users/Saul/Desktop/DISCO.dk
/*
parts[0] es "mkdisk"
*/
var re = regexp.MustCompile(`-(\w+)(?:=("[^"]+"|\S+))?`)

func getCommandAndParams(input string) (string, string) {
	parts := strings.Fields(input)
	if len(parts) > 0 {
		command := strings.ToLower(parts[0])
		params := strings.Join(parts[1:], " ")
		return command, params
	}
	return "", input

	/*Después de procesar la entrada:
	command será "mkdisk".
	params será "-size=3000 -unit=K -fit=BF -path=/home/cerezo/Disks/disk1.bin".*/
}

func Analyze() {

	for true {
		var input string
		fmt.Println(">>>>>>>>>>>>>>>>>>>>>>>>> INGRESE UN COMANDO <<<<<<<<<<<<<<<<<<<<<<<<<")
		fmt.Println("Ingrese comando: ")

		scanner := bufio.NewScanner(os.Stdin)
		scanner.Scan()
		input = scanner.Text()

		command, params := getCommandAndParams(input)

		fmt.Println("Comando: ", command, " - ", "Parametro: ", params)

		AnalyzeCommnad(command, params)

		//mkdisk -size=3000 -unit=K -fit=BF -path="/home/cerezo/Disks/disk1.bin"
	}
}

func AnalyzeScript(script string) string {
	var output bytes.Buffer

	// Separar por líneas
	lines := strings.Split(script, "\n")

	for _, line := range lines {
		line = strings.TrimSpace(line)

		// Ignorar líneas vacías o comentarios
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}

		command, params := getCommandAndParams(line)
		output.WriteString(fmt.Sprintf("Comando: %s - Parametro: %s\n", command, params))

		// Redirigir la salida a un buffer en lugar de imprimir en consola
		oldOutput := os.Stdout
		r, w, _ := os.Pipe()
		os.Stdout = w

		AnalyzeCommnad(command, params) // Ejecuta el comando

		w.Close()
		var buf bytes.Buffer
		buf.ReadFrom(r)
		os.Stdout = oldOutput

		// Agregar la salida capturada al resultado
		output.WriteString(buf.String())
		output.WriteString("\n")
	}

	return output.String()
}

func AnalyzeCommnad(command string, params string) {

	// (CAMBIO) Igualdad exacta en vez de strings.Contains para evitar choques (mount vs mounted)
	switch command {
	case "mkdisk":
		fn_mkdisk(params)
	case "fdisk":
		fn_fdisk(params)
	case "mounted":
		Management.Mounted()
	case "mount":
		fn_mount(params)
	case "mkfs":
		fn_mkfs(params)
	case "mkfile":
		fn_mkfile(params)
	case "mkdir":
		fn_mkdir(params)
	case "rmdisk":
		fn_rmdisk(params)
	case "login":
		fn_login(params)
	case "logout":
		User.Logout()
	case "mkgrp":
		fn_mkgrp(params)
	case "rmgrp":
		fn_rmgrp(params)
	case "cat":
		fn_cat(params)
	case "rep":
		fn_rep(params)
	case "salir":
		fmt.Println("Saliendo del programa...")
		os.Exit(0) // Termina la ejecución del programa
	default:
		fmt.Println("Error: Commando invalido o no encontrado")
	}

}

func fn_mkdisk(params string) {
	// Definir flag
	fs := flag.NewFlagSet("mkdisk", flag.ExitOnError)
	size := fs.Int("size", 0, "Tamaño")
	fit := fs.String("fit", "ff", "Ajuste")
	unit := fs.String("unit", "m", "Unidad")
	path := fs.String("path", "", "Ruta")

	// (CAMBIO) No parsear os.Args del proceso; inicializar vacío
	fs.Parse([]string{})

	///----------------------------------------------------- extrae y asigna los valores de los parámetros
	matches := re.FindAllStringSubmatch(params, -1)

	// Process the input
	for _, match := range matches {
		flagName := match[1] // match[1]: Captura y guarda el nombre del flag (por ejemplo, "size", "unit", "fit", "path")

		switch flagName {
		case "size", "fit", "unit":
			flagValue := strings.ToLower(match[2]) //strings.ToLower(match[2]): Captura y guarda el valor del flag, asegurándose de que esté en minúsculas
			flagValue = strings.Trim(flagValue, "\"")
			fs.Set(flagName, flagValue)
		case "path":
			flagValue := match[2]
			flagValue = strings.Trim(flagValue, "\"")
			fs.Set(flagName, flagValue)
		default:
			fmt.Println("Error: Flag not found")
			return
		}
	}
	///-----------------------------------------------------
	/*
			Primera Iteración :
		    flagName es "size".
		    flagValue es "3000".
		    El switch encuentra que "size" es un flag reconocido, por lo que se ejecuta fs.Set("size", "3000").
		    Esto asigna el valor 3000 al flag size.

	*/

	// Validaciones
	if *size <= 0 {
		fmt.Println("Error: Size must be greater than 0")
		return
	}

	if *fit != "bf" && *fit != "ff" && *fit != "wf" {
		fmt.Println("Error: Fit must be 'bf', 'ff', or 'wf'")
		return
	}

	if *unit != "k" && *unit != "m" {
		fmt.Println("Error: Unit must be 'k' or 'm'")
		return
	}

	if *path == "" {
		fmt.Println("Error: Path is required")
		return
	}

	// LLamamos a la funcion
	Management.Mkdisk(*size, *fit, *unit, *path)
}

func fn_rmdisk(params string) {
	// Definir flag
	fs := flag.NewFlagSet("rmdisk", flag.ExitOnError)
	path := fs.String("path", "", "Ruta del disco a eliminar")

	// (CAMBIO) No parsear os.Args
	fs.Parse([]string{})

	// Extraemos y asignamos los valores
	matches := re.FindAllStringSubmatch(params, -1)

	for _, match := range matches {
		flagName := match[1]
		flagValue := match[2]
		flagValue = strings.Trim(flagValue, "\"")

		switch flagName {
		case "path":
			fs.Set(flagName, flagValue)
		default:
			fmt.Println("Error: Flag no encontrado")
			return
		}
	}

	// Validaciones
	if *path == "" {
		fmt.Println("Error: Path es requerido")
		return
	}

	// Verificar si el archivo existe y no es un directorio
	info, err := os.Stat(*path)
	if os.IsNotExist(err) {
		fmt.Printf("Error: El archivo en la ruta '%s' no existe.\n", *path)
		return
	}

	if err != nil {
		fmt.Printf("Error al verificar el archivo: %v\n", err)
		return
	}

	if info.IsDir() {
		fmt.Printf("Error: La ruta '%s' es un directorio, no se puede eliminar como archivo.\n", *path)
		return
	}

	// Eliminar el archivo
	err = os.Remove(*path)
	if err != nil {
		fmt.Printf("Error: No se pudo eliminar el disco en la ruta '%s': %v\n", *path, err)
		return
	}

	fmt.Printf("Disco en la ruta '%s' eliminado correctamente.\n", *path)
}

func fn_fdisk(input string) {
	// Definir flags
	//flag.ExitOnError hace que el programa termine si hay un error al analizar los flags.
	fs := flag.NewFlagSet("fdisk", flag.ExitOnError)
	size := fs.Int("size", 0, "Tamaño")
	path := fs.String("path", "", "Ruta")
	name := fs.String("name", "", "Nombre")
	unit := fs.String("unit", "k", "Unidad")
	type_ := fs.String("type", "p", "Tipo")
	fit := fs.String("fit", "", "Ajuste") // Dejar fit vacío por defecto

	// (CAMBIO) No parsear os.Args
	fs.Parse([]string{})

	// Encontrar los flags en el input
	matches := re.FindAllStringSubmatch(input, -1)

	// Procesar el input
	for _, match := range matches {
		flagName := match[1]

		switch flagName {
		case "size", "fit", "unit", "type":
			flagValue := strings.ToLower(match[2])
			flagValue = strings.Trim(flagValue, "\"")
			fs.Set(flagName, flagValue)
		case "path", "name":
			flagValue := match[2]
			flagValue = strings.Trim(flagValue, "\"")
			fs.Set(flagName, flagValue)
		default:
			fmt.Println("Error: Flag not found")
			return
		}
	}

	// Validaciones
	if *size <= 0 {
		fmt.Println("Error: Size must be greater than 0")
		return
	}

	if *path == "" {
		fmt.Println("Error: Path is required")
		return
	}
	if *name == "" {
		fmt.Println("Error: Name is required")
		return
	}

	// Si no se proporcionó un fit, usar el valor predeterminado "w"
	if *fit == "" {
		*fit = "wf"
	}

	// Validar fit (bf/wf/ff)
	if *fit != "bf" && *fit != "ff" && *fit != "wf" {
		fmt.Println("Error: Fit must be 'bf', 'ff', or 'wf'")
		return
	}

	if *unit != "k" && *unit != "m" && *unit != "b" {
		fmt.Println("Error: Unit must be 'k' or 'm' or 'b'")
		return
	}

	if *unit == "" {
		*unit = "k"
	}
	if *type_ != "p" && *type_ != "e" && *type_ != "l" {
		fmt.Println("Error: Type must be 'p', 'e', or 'l'")
		return
	}

	// Llamar a la función
	Management.Fdisk(*size, *path, *name, *unit, *type_, *fit)
}

func fn_mount(params string) {
	fs := flag.NewFlagSet("mount", flag.ExitOnError)
	path := fs.String("path", "", "Ruta")
	name := fs.String("name", "", "Nombre de la partición")

	// (CAMBIO) No parsear osArgs
	fs.Parse([]string{})
	matches := re.FindAllStringSubmatch(params, -1)

	for _, match := range matches {
		flagName := match[1]
		flagValue := match[2] // Convertir todo a minúsculas
		flagValue = strings.Trim(flagValue, "\"")
		fs.Set(flagName, flagValue)
	}

	if *path == "" || *name == "" {
		fmt.Println("Error: Path y Name son obligatorios")
		return
	}

	// Convertir el nombre a minúsculas antes de pasarlo al Mount
	Management.Mount(*path, *name)
}

func fn_mkfs(input string) {
	fs := flag.NewFlagSet("mkfs", flag.ExitOnError)
	id := fs.String("id", "", "Id")
	type_ := fs.String("type", "", "Tipo")
	fs_ := fs.String("fs", "2fs", "Fs")

	// (CAMBIO) No parsear os.Args
	// Parse the input string, not os.Args
	fs.Parse([]string{})

	matches := re.FindAllStringSubmatch(input, -1)

	for _, match := range matches {
		flagName := match[1]
		flagValue := match[2]

		flagValue = strings.Trim(flagValue, "\"")

		switch flagName {
		case "id", "type", "fs":
			fs.Set(flagName, flagValue)
		default:
			fmt.Println("Error: Flag not found")
		}
	}

	// Verifica que se hayan establecido todas las flags necesarias
	if *id == "" {
		fmt.Println("Error: id es un parámetro obligatorio.")
		return
	}

	if *type_ == "" {
		fmt.Println("Error: type es un parámetro obligatorio.")
		return
	}

	// (CAMBIO) Normalizar ID a MAYÚSCULAS para buscar en registry
	*id = strings.ToUpper(strings.TrimSpace(*id))

	// Llamar a la función
	FileSystem.Mkfs(*id, *type_, *fs_)
}

func fn_login(input string) {
	// Definir las flags
	fs := flag.NewFlagSet("login", flag.ExitOnError)
	user := fs.String("user", "", "Usuario")
	pass := fs.String("pass", "", "Contraseña")
	id := fs.String("id", "", "Id")

	// (CAMBIO) No parsear os.Args
	fs.Parse([]string{})

	// Match de flags en el input
	matches := re.FindAllStringSubmatch(input, -1)

	// Procesar el input
	for _, match := range matches {
		flagName := match[1]
		flagValue := match[2]

		flagValue = strings.Trim(flagValue, "\"")

		switch flagName {
		case "user", "pass", "id":
			fs.Set(flagName, flagValue)
		default:
			fmt.Println("Error: Flag not found")
		}
	}
	if *user == "" {
		fmt.Println("Error: El parámetro -user es obligatorio")
		return
	}
	if *pass == "" {
		fmt.Println("Error: El parámetro -pass es obligatorio")
		return
	}
	if *id == "" {
		fmt.Println("Error: El parámetro -id es obligatorio")
		return
	}

	// (CAMBIO) Normalizar ID a MAYÚSCULAS
	*id = strings.ToUpper(strings.TrimSpace(*id))

	User.Login(*user, *pass, *id)
}

func fn_mkgrp(params string) {
	fs := flag.NewFlagSet("mkgrp", flag.ExitOnError)
	name := fs.String("name", "", "Nombre del grupo")

	// (CAMBIO) No parsear os.Args
	fs.Parse([]string{})
	matches := re.FindAllStringSubmatch(params, -1)

	for _, match := range matches {
		flagName := match[1]
		flagValue := strings.Trim(match[2], "\"") // Quitar comillas

		switch flagName {
		case "name":
			fs.Set(flagName, flagValue)
		default:
			fmt.Println("Error: Flag no reconocida")
			return
		}
	}

	if *name == "" {
		fmt.Println("Error: El parámetro -name es obligatorio")
		return
	}

	User.MKGRP(*name)
}

func fn_rmgrp(params string) {
	// (CAMBIO) Corregido nombre del FlagSet (antes decía "mkgrp")
	fs := flag.NewFlagSet("rmgrp", flag.ExitOnError)
	name := fs.String("name", "", "Nombre del grupo")

	// (CAMBIO) No parsear os.Args
	fs.Parse([]string{})
	matches := re.FindAllStringSubmatch(params, -1)

	for _, match := range matches {
		flagName := match[1]
		flagValue := strings.Trim(match[2], "\"") // Quitar comillas

		switch flagName {
		case "name":
			fs.Set(flagName, flagValue)
		default:
			fmt.Println("Error: Flag no reconocida")
			return
		}
	}

	if *name == "" {
		fmt.Println("Error: El parámetro -name es obligatorio")
		return
	}

	User.RMGRP(*name)
}

func fn_mkfile(params string) {
	// Definir flag
	fs := flag.NewFlagSet("mkfile", flag.ExitOnError)
	path := fs.String("path", "", "Ruta")
	r := fs.Bool("r", false, "Carpetas Padres")
	size := fs.Int("size", 0, "Tamanio")
	cont := fs.String("cont", "", "Contenido")

	// (CAMBIO) No parsear os.Args
	fs.Parse([]string{})

	///----------------------------------------------------- extrae y asigna los valores de los parámetros
	matches := re.FindAllStringSubmatch(params, -1)
	// Process the input
	for _, match := range matches {
		flagName := match[1]  // match[1]: Captura y guarda el nombre del flag (por ejemplo, "size", "unit", "fit", "path")
		flagValue := match[2] //trings.ToLower(match[2]): Captura y guarda el valor del flag, asegurándose de que esté en minúsculas

		flagValue = strings.Trim(flagValue, "\"")
		fmt.Println("flagName: ", flagName)
		fmt.Println("flagValue: ", flagValue)
		switch flagName {
		case "size", "path", "cont":
			fs.Set(flagName, flagValue)
		case "r":
			fs.Set(flagName, "true")
		default:
			fmt.Println("Error: Flag not found")
		}
	}

	// Validaciones
	if *size < 0 {
		fmt.Println("Error: Size must be greater or equal than 0")
		return
	}

	if *path == "" {
		fmt.Println("Error: Path is required")
		return
	}

	// LLamamos a la funcion
	Management.MkFile(*path, *size, *r, *cont)
}

func fn_mkdir(params string) {
	// Definir flag
	fs := flag.NewFlagSet("mkdir", flag.ExitOnError)
	path := fs.String("path", "", "Ruta")
	p := fs.Bool("p", false, "Carpetas Padres")

	// (CAMBIO) No parsear os.Args
	fs.Parse([]string{})

	///----------------------------------------------------- extrae y asigna los valores de los parámetros
	matches := re.FindAllStringSubmatch(params, -1)
	// Process the input
	for _, match := range matches {
		flagName := match[1]  // match[1]: Captura y guarda el nombre del flag (por ejemplo, "size", "unit", "fit", "path")
		flagValue := match[2] //trings.ToLower(match[2]): Captura y guarda el valor del flag, asegurándose de que esté en minúsculas

		flagValue = strings.Trim(flagValue, "\"")
		switch flagName {
		case "path":
			fs.Set(flagName, flagValue)
		case "p":
			fs.Set(flagName, "true")
		default:
			fmt.Println("Error: Flag not found")
		}
	}

	if *path == "" {
		fmt.Println("Error: Path is required")
		return
	}

	// LLamamos a la funcion
	Management.Mkdir(*path, *p)
}

func fn_cat(params string) {
	fmt.Println("======Start CAT======")
	// Extrae todos los parámetros que empiecen con -file
	re := regexp.MustCompile(`-file\d+=("[^"]+"|\S+)`)
	matches := re.FindAllStringSubmatch(params, -1)

	if len(matches) == 0 {
		fmt.Println("Error: Debe especificar al menos un archivo con -fileN=")
		return
	}

	var filePaths []string
	for _, match := range matches {
		param := strings.Trim(match[1], "\"")
		filePaths = append(filePaths, param)
	}

	// Llamar a la función que lee y concatena los archivos
	content, err := User.ReadMultipleFiles(filePaths)
	if err != nil {
		fmt.Println("Error al leer archivos:", err)
		return
	}

	fmt.Println("====== CONTENIDO DE LOS ARCHIVOS ======")
	fmt.Println(content)
	fmt.Println("======End CAT======")
}

func fn_rep(params string) (string, error) {
	// Definir flags para el comando rep
	fs := flag.NewFlagSet("rep", flag.ExitOnError)
	name := fs.String("name", "", "Nombre del reporte a generar (mbr, disk, inode, block, bm_inode, bm_block, sb, file, ls)")
	path := fs.String("path", "", "Ruta donde se guardará el reporte")
	id := fs.String("id", "", "ID de la partición que se utilizará")
	pathFileLs := fs.String("path_file_ls", "", "Nombre del archivo o carpeta para los reportes 'file' y 'ls'")

	// (CAMBIO) No parsear os.Args
	fs.Parse([]string{})
	// Match de flags en el input
	matches := re.FindAllStringSubmatch(params, -1)

	// Procesar los parámetros del input
	for _, match := range matches {
		flagName := match[1]
		flagValue := match[2]
		flagValue = strings.Trim(flagValue, "\"")

		switch flagName {
		case "name", "path", "id", "path_file_ls":
			fs.Set(flagName, flagValue)
		default:
			fmt.Printf("parámetro inválido: %s\n", flagName)
			return "", fmt.Errorf("parámetro inválido: %s", flagName)
		}
	}

	// Validar los parámetros obligatorios
	if *name == "" {
		fmt.Println("Error: El parámetro -name es obligatorio y debe contener un valor válido (mbr, disk, inode, block, bm_inode, bm_block, sb, file, ls)")
		return "", fmt.Errorf("parámetro inválido: %s", *name)
	}

	if *path == "" {
		fmt.Println("Error: El parámetro -path es obligatorio.")
		return "", fmt.Errorf("parámetro inválido: %s", *path)
	}

	if *id == "" {
		fmt.Println("Error: El parámetro -id es obligatorio.")
		return "", fmt.Errorf("parámetro inválido: %s", *id)
	}

	// Verificar que el nombre del reporte es válido
	// (CAMBIO) Agregado "tree"
	validReports := []string{"mbr", "disk", "inode", "block", "bm_inode", "bm_block", "sb", "file", "ls", "tree"}
	if !isValidReportName(*name, validReports) {
		fmt.Println("Error: Nombre de reporte no válido.")
		return "", fmt.Errorf("parámetro inválido: %s", *name)
	}

	// (CAMBIO) Normalizar ID a MAYÚSCULAS antes de buscar
	*id = strings.ToUpper(strings.TrimSpace(*id))

	// Verificar que la partición con el id existe
	partition := Management.GetPartitionByID(*id)
	if partition == nil {
		fmt.Println("Error: No se encontró la partición con el id proporcionado.")
		return "", fmt.Errorf("partición no encontrada: %s", *id)
	}

	// Generar el reporte con Graphviz
	switch *name {
	case "mbr":
		Management.GenerateMBRReport(*path, *partition)
	case "disk":
		Management.GenerateDiskReport(*path, partition)
	case "inode":
		Management.GenerateInodeReport(*path, partition)
	case "block":
		Management.GenerateBlockReport(*path, partition)
	case "bm_inode":
		Management.GenerateBMInodeReport(*path, partition)
	case "bm_block":
		Management.GenerateBMBlockReport(*path, partition)
	case "sb":
		Management.GenerateSuperblockReport(*path, partition)
	case "file":
		if *pathFileLs == "" {
			fmt.Println("Error: El parámetro -path_file_ls es obligatorio para el reporte file.")
			return "", fmt.Errorf("parámetro inválido: %s", *pathFileLs)
		}
		Rep.GenerateFileReport(*path, partition, *pathFileLs)
	case "ls":
		if *pathFileLs == "" {
			fmt.Println("Error: El parámetro -path_file_ls es obligatorio para el reporte ls.")
			return "", fmt.Errorf("parámetro inválido: %s", *pathFileLs)
		}
		Management.GenerateLsReport(*path, *partition, *pathFileLs)
	case "tree":
		// (CAMBIO) Soporte para 'tree' (ajusta el nombre si tu implementación difiere)
		//Management.GenerateTreeReport(*path, *partition)
		fmt.Println("Error: La funcionalidad para el reporte 'tree' no está implementada.")
	default:
		fmt.Println("Error: Nombre de reporte no válido.")
	}
	return "REP: Reporte " + *name + " exitosamente en: " + *path, nil
}

// Verifica si el nombre del reporte es válido
func isValidReportName(name string, validReports []string) bool {
	for _, report := range validReports {
		if name == report {
			return true
		}
	}
	return false
}
