package Management

import (
	"MIA_P1/backend/ActSession"
	"MIA_P1/backend/Structs"
	"MIA_P1/backend/Utilities"
	"bytes"
	"encoding/binary"
	"fmt"
	"math/rand"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
	"unsafe"
)

// Estructura para representar una partición montada
type MountedPartition struct {
	Path     string
	Name     string
	ID       string
	Status   byte // 0: no montada, 1: montada
	LoggedIn bool // true: usuario ha iniciado sesión, false: no ha iniciado sesión
}

// Mapa para almacenar las particiones montadas, organizadas por disco
var mountedPartitions = make(map[string][]MountedPartition)

// Función para imprimir las particiones montadas
func PrintMountedPartitions() {
	fmt.Println("Particiones montadas:")

	if len(mountedPartitions) == 0 {
		fmt.Println("No hay particiones montadas.")
		return
	}

	for diskID, partitions := range mountedPartitions {
		fmt.Printf("Disco ID: %s\n", diskID)
		for _, partition := range partitions {
			fmt.Printf(" - Partición Name: %s, ID: %s, Path: %s, Status: %c\n",
				partition.Name, partition.ID, partition.Path, partition.Status)
		}
	}
	fmt.Println("")
}

// MarkPartitionAsLoggedIn busca una partición por su ID y la marca como logueada (LoggedIn = true).
func MarkPartitionAsLoggedIn(id string) {
	// Recorre todas las particiones montadas en los discos.
	for diskID, partitions := range mountedPartitions {
		for i, partition := range partitions {
			// Si la partición coincide con el ID buscado, se marca como logueada.
			if partition.ID == id {
				mountedPartitions[diskID][i].LoggedIn = true
				fmt.Printf("Partición con ID %s marcada como logueada.\n", id)
				return
			}
		}
	}
	// Si no se encuentra la partición, se muestra un mensaje de error.
	fmt.Printf("No se encontró la partición con ID %s para marcarla como logueada.\n", id)
}

func MarkPartitionAsLoggedOut(id string) {
	// Recorre todas las particiones montadas en los discos.
	for diskID, partitions := range mountedPartitions {
		for i, partition := range partitions {
			// Si la partición coincide con el ID buscado, se marca como logueada.
			if partition.ID == id {
				mountedPartitions[diskID][i].LoggedIn = false
				fmt.Printf("Partición con ID %s marcada como logout.\n", id)
				return
			}
		}
	}
	// Si no se encuentra la partición, se muestra un mensaje de error.
	fmt.Printf("No se encontró la partición con ID %s para marcarla como logueada.\n", id)
}

func Mounted() {
	if len(mountedPartitions) == 0 {
		fmt.Println("No hay particiones montadas en el sistema.")
		return
	}

	fmt.Println("========================= Particiones Montadas =========================")

	// Iterar sobre todos los discos montados
	for diskPath, partitions := range mountedPartitions {
		fmt.Printf("Disco ID: %s\n", diskPath)
		for _, partition := range partitions {
			fmt.Printf(" - Partición Name: %s, ID: %s, Path: %s\n",
				partition.Name, partition.ID, partition.Path)
		}
	}
}

// Función para obtener las particiones montadas
func GetMountedPartitions() map[string][]MountedPartition {
	return mountedPartitions
}

// ////////////////////////////////////////////////////////////////////////////
func Mkdisk(size int, fit string, unit string, path string) {
	fmt.Println("======INICIO MKDISK======")
	fmt.Printf("Size: %d\nFit: %s\nUnit: %s\nPath: %s\n", size, fit, unit, path)

	// Validaciones
	if fit != "bf" && fit != "wf" && fit != "ff" {
		fmt.Println("Error: Fit debe ser 'bf', 'wf' o 'ff'")
		return
	}
	if size <= 0 {
		fmt.Println("Error: Size debe ser mayor a 0")
		return
	}
	if unit != "k" && unit != "m" {
		fmt.Println("Error: Las unidades válidas son 'k' o 'm'")
		return
	}

	// Crear archivo
	if err := Utilities.CreateFile(path); err != nil {
		fmt.Println("Error al crear archivo:", err)
		return
	}

	// Convertir tamaño a bytes
	if unit == "k" {
		size = size * 1024
	} else {
		size = size * 1024 * 1024
	}

	// Abrir archivo
	file, err := Utilities.OpenFile(path)
	if err != nil {
		fmt.Println("Error al abrir archivo:", err)
		return
	}
	defer file.Close() // Asegura el cierre del archivo al salir de la función

	// Escribir ceros en un solo bloque en lugar de un bucle
	zeroBlock := make([]byte, size) // Crea un slice de bytes lleno de ceros
	if _, err := file.Write(zeroBlock); err != nil {
		fmt.Println("Error al escribir en el archivo:", err)
		return
	}

	// Crear MBR
	var newMBR Structs.MRB
	newMBR.MbrSize = int32(size)
	newMBR.Signature = rand.Int31()
	copy(newMBR.Fit[:], fit)

	// Obtener fecha actual en formato YYYY-MM-DD
	formattedDate := time.Now().Format("2006-01-02")
	copy(newMBR.CreationDate[:], formattedDate)

	// Escribir el MBR en el archivo
	if err := Utilities.WriteObject(file, newMBR, 0); err != nil {
		fmt.Println("Error al escribir el MBR:", err)
		return
	}

	// Leer el MBR para verificar que se escribió correctamente
	var tempMBR Structs.MRB
	if err := Utilities.ReadObject(file, &tempMBR, 0); err != nil {
		fmt.Println("Error al leer el MBR:", err)
		return
	}

	// Imprimir el MBR leído
	Structs.PrintMBR(tempMBR)
	mountedPartitions = make(map[string][]MountedPartition) // Reiniciar el mapa de particiones montadas
	fmt.Println("======FIN MKDISK======")
}

func Fdisk(size int, path string, name string, unit string, type_ string, fit string) {
	fmt.Println("======Start FDISK======")
	fmt.Println("Size:", size)
	fmt.Println("Path:", path)
	fmt.Println("Name:", name)
	fmt.Println("Unit:", unit)
	fmt.Println("Type:", type_)
	fmt.Println("Fit:", fit)

	// Validar fit (b/w/f)
	if fit != "bf" && fit != "ff" && fit != "wf" {
		fmt.Println("Error: Fit must be 'bf', 'ff', or 'wf'")
		return
	}

	// Validar size > 0
	if size <= 0 {
		fmt.Println("Error: Size must be greater than 0")
		return
	}

	// Validar unit (b/k/m)
	if unit != "b" && unit != "k" && unit != "m" {
		fmt.Println("Error: Unit must be 'b', 'k', or 'm'")
		return
	}

	// Ajustar el tamaño en bytes
	if unit == "k" {
		size = size * 1024
	} else if unit == "m" {
		size = size * 1024 * 1024
	}

	// Abrir el archivo binario en la ruta proporcionada
	file, err := Utilities.OpenFile(path)
	if err != nil {
		fmt.Println("Error: Could not open file at path:", path)
		return
	}

	var TempMBR Structs.MRB
	// Leer el objeto desde el archivo binario
	if err := Utilities.ReadObject(file, &TempMBR, 0); err != nil {
		fmt.Println("Error: Could not read MBR from file")
		return
	}

	// Imprimir el objeto MBR
	Structs.PrintMBR(TempMBR)

	fmt.Println("-------------")

	// Validaciones de las particiones
	var primaryCount, extendedCount, totalPartitions int
	var usedSpace int32 = 0

	for i := 0; i < 4; i++ {
		if TempMBR.Partitions[i].Size != 0 {
			totalPartitions++
			usedSpace += TempMBR.Partitions[i].Size

			if TempMBR.Partitions[i].Type[0] == 'p' {
				primaryCount++
			} else if TempMBR.Partitions[i].Type[0] == 'e' {
				extendedCount++
			}
		}
	}

	// Validar que no se exceda el número máximo de particiones primarias y extendidas
	if totalPartitions >= 4 {
		fmt.Println("Error: No se pueden crear más de 4 particiones primarias o extendidas en total.")
		return
	}

	// Validar que solo haya una partición extendida
	if type_ == "e" && extendedCount > 0 {
		fmt.Println("Error: Solo se permite una partición extendida por disco.")
		return
	}

	// Validar que no se pueda crear una partición lógica sin una extendida
	if type_ == "l" && extendedCount == 0 {
		fmt.Println("Error: No se puede crear una partición lógica sin una partición extendida.")
		return
	}

	// Validar que el tamaño de la nueva partición no exceda el tamaño del disco
	if usedSpace+int32(size) > TempMBR.MbrSize {
		fmt.Println("Error: No hay suficiente espacio en el disco para crear esta partición.")
		return
	}

	// Determinar la posición de inicio de la nueva partición
	var gap int32 = int32(binary.Size(TempMBR))
	if totalPartitions > 0 {
		gap = TempMBR.Partitions[totalPartitions-1].Start + TempMBR.Partitions[totalPartitions-1].Size
	}

	// Encontrar una posición vacía para la nueva partición
	for i := 0; i < 4; i++ {
		if TempMBR.Partitions[i].Size == 0 {
			if type_ == "p" || type_ == "e" {
				// Crear partición primaria o extendida
				TempMBR.Partitions[i].Size = int32(size)
				TempMBR.Partitions[i].Start = gap
				copy(TempMBR.Partitions[i].Name[:], name)
				copy(TempMBR.Partitions[i].Fit[:], fit)
				copy(TempMBR.Partitions[i].Status[:], "0")
				copy(TempMBR.Partitions[i].Type[:], type_)
				TempMBR.Partitions[i].Correlative = int32(totalPartitions + 1)

				if type_ == "e" {
					// Inicializar el primer EBR en la partición extendida
					ebrStart := gap // El primer EBR se coloca al inicio de la partición extendida
					ebr := Structs.EBR{
						PartFit:   fit[0],
						PartStart: ebrStart,
						PartSize:  0,
						PartNext:  -1,
					}
					copy(ebr.PartName[:], "")
					Utilities.WriteObject(file, ebr, int64(ebrStart))
				}

				break
			}
		}
	}

	// Manejar la creación de particiones lógicas dentro de una partición extendida
	if type_ == "l" {
		for i := 0; i < 4; i++ {
			if TempMBR.Partitions[i].Type[0] == 'e' {
				ebrPos := TempMBR.Partitions[i].Start
				var ebr Structs.EBR
				for {
					Utilities.ReadObject(file, &ebr, int64(ebrPos))
					if ebr.PartNext == -1 {
						break
					}
					ebrPos = ebr.PartNext
				}

				// Calcular la posición de inicio de la nueva partición lógica
				newEBRPos := ebr.PartStart + ebr.PartSize                    // El nuevo EBR se coloca después de la partición lógica anterior
				logicalPartitionStart := newEBRPos + int32(binary.Size(ebr)) // El inicio de la partición lógica es justo después del EBR

				// Ajustar el siguiente EBR
				ebr.PartNext = newEBRPos
				Utilities.WriteObject(file, ebr, int64(ebrPos))

				// Crear y escribir el nuevo EBR
				newEBR := Structs.EBR{
					PartFit:   fit[0],
					PartStart: logicalPartitionStart,
					PartSize:  int32(size),
					PartNext:  -1,
				}
				copy(newEBR.PartName[:], name)
				Utilities.WriteObject(file, newEBR, int64(newEBRPos))

				// Imprimir el nuevo EBR creado
				fmt.Println("Nuevo EBR creado:")
				Structs.PrintEBR(newEBR)
				fmt.Println("")

				// Imprimir todos los EBRs en la partición extendida
				fmt.Println("Imprimiendo todos los EBRs en la partición extendida:")
				ebrPos = TempMBR.Partitions[i].Start
				for {
					err := Utilities.ReadObject(file, &ebr, int64(ebrPos))
					if err != nil {
						fmt.Println("Error al leer EBR:", err)
						break
					}
					Structs.PrintEBR(ebr)
					if ebr.PartNext == -1 {
						break
					}
					ebrPos = ebr.PartNext
				}

				break
			}
		}
		fmt.Println("")
	}

	// Sobrescribir el MBR
	if err := Utilities.WriteObject(file, TempMBR, 0); err != nil {
		fmt.Println("Error: Could not write MBR to file")
		return
	}

	var TempMBR2 Structs.MRB
	// Leer el objeto nuevamente para verificar
	if err := Utilities.ReadObject(file, &TempMBR2, 0); err != nil {
		fmt.Println("Error: Could not read MBR from file after writing")
		return
	}

	// Imprimir el objeto MBR actualizado
	Structs.PrintMBR(TempMBR2)

	// Cerrar el archivo binario
	defer file.Close()

	fmt.Println("======FIN FDISK======")
	fmt.Println("")

}

func MkFile(path string, size int, r bool, cont string) {
	fmt.Println("======Start MKFILE======")
	fmt.Println("Path:", path)
	fmt.Println("Size:", size)
	fmt.Println("r:", r)
	fmt.Println("Cont:", cont)

	session := ActSession.GetSession()
	if !session.IsActive {
		fmt.Println("Error: No hay ninguna sesión activa. Debe hacer login primero.")
		return
	}
	// Validar tamaño
	if size < 0 {
		fmt.Println("Error: Size must be greater than 0")
		return
	}
	partition := GetMountedPartition()

	if cont != "" {
		fileBytes, err := os.ReadFile(cont)
		if err != nil {
			fmt.Println("Error al leer el archivo de contenido:", err)
			return
		}
		cont = string(fileBytes)
		// Si no se especificó size, usamos el tamaño del contenido
		if size == 0 {
			size = len(cont)
		}
	} else {
		cont = generateContent(size)
	}

	err := createFile(path, size, cont, r, partition)
	if err != nil {
		fmt.Println("Error al crear el archivo:", err)
		return
	}
	fmt.Println("Archivo creado exitosamente.")
	fmt.Println("======FIN MKFILE======")

}

// Mkdir crea directorios de manera jerárquica en el sistema de archivos
func Mkdir(path string, p bool) error {
	// Variable para acumular los mensajes
	var logs string

	// Agregar los mensajes de inicio al log
	logs += "======INICIO MKDIR======\n"
	logs += fmt.Sprintf("Path: %s\n", path)

	// Verificar si hay una partición logueada
	if ActSession.ActiveSession.ID == "" {
		fmt.Println("No hay ninguna partición logueada")

		return fmt.Errorf("No hay ninguna partición logueada")
	}

	// Buscar la partición montada por ID
	var mountedPartition MountedPartition
	var partitionFound bool

	for _, partitions := range GetMountedPartitions() {
		for _, partition := range partitions {
			if partition.ID == ActSession.ActiveSession.ID {
				mountedPartition = partition
				partitionFound = true
				break
			}
		}
		if partitionFound {
			break
		}
	}

	if !partitionFound {
		errMsg := "Partición no encontrada"
		logs += errMsg + "\n"
		fmt.Println(errMsg)
		return fmt.Errorf(errMsg)
	}

	if mountedPartition.Status != '1' { // Verifica si la partición está montada
		errMsg := "La partición aún no está montada"
		logs += errMsg + "\n"
		fmt.Println(errMsg)
		return fmt.Errorf(errMsg)
	}

	// Abrir archivo binario
	file, err := Utilities.OpenFile(mountedPartition.Path)
	if err != nil {
		errMsg := fmt.Sprintf("Error al abrir el archivo: %v", err)
		logs += errMsg + "\n"
		fmt.Println(errMsg)
		return fmt.Errorf(errMsg)
	}
	defer file.Close()

	var TempMBR Structs.MRB
	// Leer objeto desde archivo binario
	if err := Utilities.ReadObject(file, &TempMBR, 0); err != nil {
		errMsg := "Error al leer MBR del archivo"
		logs += errMsg + "\n"
		fmt.Println(errMsg)
		return fmt.Errorf(errMsg)
	}

	var index int = -1
	// Iterar sobre las particiones para encontrar la que tiene el nombre correspondiente
	for i := 0; i < 4; i++ {
		if TempMBR.Partitions[i].Size != 0 {
			if strings.Contains(string(TempMBR.Partitions[i].Id[:]), ActSession.ActiveSession.ID) {
				index = i
				break
			}
		}
	}

	if index != -1 {
		logs += fmt.Sprintf("Partición encontrada: %s\n", string(TempMBR.Partitions[index].Name[:]))
		fmt.Println("Partición encontrada: %s", string(TempMBR.Partitions[index].Name[:]))
	} else {
		errMsg := "Partición no encontrada (2)"
		logs += errMsg + "\n"
		fmt.Println(errMsg)
		return fmt.Errorf(errMsg)
	}

	// Leer el superbloque
	var superblock Structs.Superblock
	if err := Utilities.ReadObject(file, &superblock, int64(TempMBR.Partitions[index].Start)); err != nil {
		errMsg := "Error al leer el superbloque"
		logs += errMsg + "\n"
		fmt.Println(errMsg)
		return fmt.Errorf(errMsg)
	}

	// Crear los directorios de la ruta de manera secuencial
	directories := strings.Split(path, "/")
	currentInode := int32(0) // Comienza en el inodo raíz (usualmente inodo 0)

	for _, dir := range directories {
		if dir == "" {
			continue
		}

		// Busca si el directorio ya existe
		found, inodeIndex := findDirectory(dir, currentInode, file, superblock)
		if found {
			// Si ya existe y -p está activado, lo ignoramos y seguimos
			currentInode = inodeIndex
		} else {
			if !p {
				// Sin -p y no existe, error
				fmt.Printf("Error: el directorio '%s' no existe y no se especificó -p\n", dir)
				return fmt.Errorf("el directorio '%s' no existe y no se especificó -p", dir)
			}
			// Crear directorio
			newInodeIndex, err := createDirectory(dir, currentInode, file, superblock)
			if err != nil {
				return fmt.Errorf("error creando directorio '%s': %v", dir, err)
			}
			currentInode = newInodeIndex
		}

	}

	logs += "======FIN MKDIR======\n"
	fmt.Printf("Directorio creado-------------: %s\n", path)
	ListDirectories()
	return nil
}

// ListDirectories recorre y lista todos los directorios en el sistema de archivos
func ListDirectories() error {
	if ActSession.ActiveSession.ID == "" {
		return fmt.Errorf("No hay ninguna partición logueada")
	}

	mountedPartition, err := findMountedPartition(ActSession.ActiveSession.ID)
	if err != nil {
		return err
	}

	file, err := Utilities.OpenFile(mountedPartition.Path)
	if err != nil {
		return fmt.Errorf("Error al abrir el archivo: %v", err)
	}
	defer file.Close()

	TempMBR, err := readMBR(file)
	if err != nil {
		return err
	}

	index := findPartitionIndex(TempMBR, ActSession.ActiveSession.ID)
	if index == -1 {
		return fmt.Errorf("Partición no encontrada (2)")
	}

	superblock, err := readSuperblock(file, int64(TempMBR.Partitions[index].Start))
	if err != nil {
		return err
	}

	return traverseDirectory(0, file, superblock)
}

func traverseDirectory(inodeIndex int32, file *os.File, superblock Structs.Superblock) error {
	inode, err := readInode(inodeIndex, file, superblock)
	if err != nil {
		return err
	}

	for _, block := range inode.I_block {
		if block == -1 {
			continue
		}

		folderblock, err := readFolderBlock(block, file, superblock)
		if err != nil {
			return err
		}

		for _, content := range folderblock.B_content {
			name := strings.TrimRight(string(content.B_name[:]), "\x00")
			if content.B_inodo != -1 && name != "." && name != ".." {
				// Verificar si el inodo es un directorio
				childInode, err := readInode(content.B_inodo, file, superblock)
				if err != nil {
					return err
				}
				if isDirectory(childInode) {
					fmt.Println("Directory:", name)
					if err := traverseDirectory(content.B_inodo, file, superblock); err != nil {
						return err
					}
				}
			}
		}
	}

	return nil
}
func readInode(inodeIndex int32, file *os.File, superblock Structs.Superblock) (Structs.Inode, error) {
	var inode Structs.Inode
	offset := int64(superblock.S_inode_start + inodeIndex*int32(binary.Size(Structs.Inode{})))
	if err := Utilities.ReadObject(file, &inode, offset); err != nil {
		return inode, fmt.Errorf("error al leer el inodo: %v", err)
	}
	return inode, nil
}

func readFolderBlock(blockIndex int32, file *os.File, superblock Structs.Superblock) (Structs.Folderblock, error) {
	var folderblock Structs.Folderblock
	offset := int64(superblock.S_block_start + blockIndex*int32(binary.Size(Structs.Folderblock{})))
	if err := Utilities.ReadObject(file, &folderblock, offset); err != nil {
		return folderblock, fmt.Errorf("error al leer el folderblock: %v", err)
	}
	return folderblock, nil
}

func isDirectory(inode Structs.Inode) bool {
	// Asumimos que el tipo de archivo se almacena en I_type
	// y que '0' representa un directorio
	return inode.I_type[0] == byte(0)
}

func findMountedPartition(id string) (MountedPartition, error) {
	for _, partitions := range GetMountedPartitions() {
		for _, partition := range partitions {
			if partition.ID == id {
				if partition.Status != '1' {
					return partition, fmt.Errorf("La partición aún no está montada")
				}
				return partition, nil
			}
		}
	}
	return MountedPartition{}, fmt.Errorf("Partición no encontrada")
}

func readMBR(file *os.File) (Structs.MRB, error) {
	var TempMBR Structs.MRB
	if err := Utilities.ReadObject(file, &TempMBR, 0); err != nil {
		return TempMBR, fmt.Errorf("Error al leer MBR del archivo")
	}
	return TempMBR, nil
}

func findPartitionIndex(TempMBR Structs.MRB, id string) int {
	for i := 0; i < 4; i++ {
		if TempMBR.Partitions[i].Size != 0 && strings.Contains(string(TempMBR.Partitions[i].Id[:]), id) {
			return i
		}
	}
	return -1
}

func readSuperblock(file *os.File, start int64) (Structs.Superblock, error) {
	var superblock Structs.Superblock
	if err := Utilities.ReadObject(file, &superblock, start); err != nil {
		return superblock, fmt.Errorf("Error al leer el superbloque")
	}
	return superblock, nil
}

// Función para crear un archivo
func createFile(filePath string, size int, content string, r bool, partition *MountedPartition) error {
	// Abrir el archivo binario de la partición
	file, err := Utilities.OpenFile(partition.Path)
	if err != nil {
		return fmt.Errorf("error al abrir el archivo: %v", err)
	}
	defer file.Close()

	// Leer el MBR para obtener el inicio de la partición
	var mbr Structs.MRB
	if err := Utilities.ReadObject(file, &mbr, 0); err != nil {
		fmt.Println("error al leer el MBR: ", err)
		return fmt.Errorf("error al leer el MBR: %v", err)
	}

	// Encontrar la partición montada
	var partitionStart int64
	for _, part := range mbr.Partitions {
		if strings.TrimSpace(string(part.Id[:])) == partition.ID {
			partitionStart = int64(part.Start)
			break
		}
	}

	if partitionStart == 0 {
		fmt.Println("Error: Partición no encontrada")
		return fmt.Errorf("error: partición no encontrada")
	}

	// Leer el superbloque
	var superblock Structs.Superblock
	if err := Utilities.ReadObject(file, &superblock, partitionStart); err != nil {
		fmt.Println("Error al leer el superbloque: ", err)
		return fmt.Errorf("error al leer el superbloque: %v", err)
	}

	// Crear los directorios padres si no existen
	parentDirs, destFile := getParentDirectories(filePath)
	currentInode := int32(0) // Asumimos que el inodo raíz es 0

	for _, dir := range parentDirs {
		if dir == "" {
			continue
		}

		// Busca si el directorio ya existe
		found, inodeIndex := findDirectory(dir, currentInode, file, superblock)
		if found {
			currentInode = inodeIndex
		} else {
			// Si no se encontró y no se especificó -r, entonces error
			if !r {
				return fmt.Errorf("error: el directorio '%s' no existe y no se especificó el parámetro -r", dir)
			}
			// Si se especificó -r, crear el directorio
			newInodeIndex, err := createDirectory(dir, currentInode, file, superblock)
			if err != nil {
				return err
			}
			currentInode = newInodeIndex
		}
	}

	// Crear el archivo en el directorio destino
	err = createFileInDirectory(destFile, currentInode, size, content, file, superblock, *partition)
	if err != nil {
		return fmt.Errorf("error al crear el archivo en el directorio destino: %w", err)
	}

	return nil
}

// Función para crear un nuevo directorio
func createDirectory(name string, parentInode int32, file *os.File, superblock Structs.Superblock) (int32, error) {
	// Encuentra un inodo libre
	newInodeIndex := findFreeInode(superblock, file)
	if newInodeIndex == -1 {
		return -1, fmt.Errorf("no hay inodos libres")
	}

	// Encuentra un bloque libre
	newBlockIndex := findFreeBlock(superblock, file)
	if newBlockIndex == -1 {
		return -1, fmt.Errorf("no hay bloques libres")
	}

	// Inicializa el nuevo inodo con valores predeterminados
	var newInode Structs.Inode
	initInode(&newInode)
	newInode.I_block[0] = newBlockIndex

	// Escribe el nuevo inodo en el archivo en la posición correcta
	inodeOffset := int64(superblock.S_inode_start + newInodeIndex*int32(binary.Size(Structs.Inode{})))
	if err := Utilities.WriteObject(file, newInode, inodeOffset); err != nil {
		return -1, fmt.Errorf("error al escribir el nuevo inodo: %v", err)
	}

	// Inicializa el nuevo folderblock y escribe en el archivo
	var newFolderblock Structs.Folderblock
	newFolderblock.B_content[0].B_inodo = newInodeIndex
	copy(newFolderblock.B_content[0].B_name[:], name)

	blockOffset := int64(superblock.S_block_start + newBlockIndex*int32(binary.Size(Structs.Folderblock{})))
	if err := Utilities.WriteObject(file, newFolderblock, blockOffset); err != nil {
		return -1, fmt.Errorf("error al escribir el folderblock: %v", err)
	}

	// Marca el inodo y el bloque como usados en los bitmaps
	if err := markInodeAsUsed(newInodeIndex, superblock, file); err != nil {
		return -1, fmt.Errorf("error al marcar el inodo como usado: %v", err)
	}
	if err := markBlockAsUsed(newBlockIndex, superblock, file); err != nil {
		return -1, fmt.Errorf("error al marcar el bloque como usado: %v", err)
	}

	// Actualiza el folderblock del inodo padre
	if err := updateParentFolderblock(name, parentInode, newInodeIndex, file, superblock); err != nil {
		return -1, fmt.Errorf("error al actualizar el folderblock del inodo padre: %v", err)
	}

	return newInodeIndex, nil
}

func findDirectory(name string, parentInode int32, file *os.File, superblock Structs.Superblock) (bool, int32) {
	var inode Structs.Inode
	offset := int64(superblock.S_inode_start + parentInode*int32(binary.Size(Structs.Inode{})))
	if err := Utilities.ReadObject(file, &inode, offset); err != nil {
		return false, -1
	}

	for _, block := range inode.I_block {
		if block == -1 {
			continue
		}

		var folderblock Structs.Folderblock
		offset := int64(superblock.S_block_start + block*int32(binary.Size(Structs.Folderblock{})))
		if err := Utilities.ReadObject(file, &folderblock, offset); err != nil {
			return false, -1
		}

		// Revisar si el nombre del directorio ya existe en el contenido del folderblock
		for _, content := range folderblock.B_content {
			trimmedName := strings.TrimRight(string(content.B_name[:]), "\x00") // Eliminar caracteres nulos
			if trimmedName == name && content.B_inodo != -1 {
				return true, content.B_inodo
			}
		}
	}

	return false, -1
}

// Función para obtener los directorios padres y el archivo destino
func getParentDirectories(filePath string) ([]string, string) {
	dirs := strings.Split(filePath, "/")
	return dirs[:len(dirs)-1], dirs[len(dirs)-1]
}

// Función para crear un archivo en un directorio
func createFileInDirectory(fileName string, parentInode int32, size int, content string, file *os.File, superblock Structs.Superblock, mountedPartition MountedPartition) error {
	// Leer el MBR para obtener el inicio de la partición
	var mbr Structs.MRB
	if err := Utilities.ReadObject(file, &mbr, 0); err != nil {
		return fmt.Errorf("error al leer el MBR: %v", err)
	}

	// Encontrar la partición montada y obtener su inicio
	var partitionStart int64
	var partitionIndex int = -1
	for i := 0; i < 4; i++ {
		if mbr.Partitions[i].Size != 0 && strings.Contains(string(mbr.Partitions[i].Id[:]), mountedPartition.ID) {
			partitionStart = int64(mbr.Partitions[i].Start)
			partitionIndex = i
			break
		}
	}

	if partitionStart == 0 {
		return fmt.Errorf("no se encontró la partición montada")
	}

	// Obtener la partición y verificar que haya sido encontrada
	if partitionIndex == -1 {
		return fmt.Errorf("no se encontró la partición correspondiente")
	}

	// Actualiza el superbloque si hay cambios en los inodos o bloques
	if err := Utilities.WriteObject(file, superblock, partitionStart); err != nil {
		return fmt.Errorf("error al actualizar el superbloque: %v", err)
	}

	// Encuentra un inodo libre
	newInodeIndex := findFreeInode(superblock, file)
	if newInodeIndex == -1 {
		return fmt.Errorf("no hay inodos libres")
	}

	// Encuentra un bloque libre
	newBlockIndex := findFreeBlock(superblock, file)
	if newBlockIndex == -1 {
		return fmt.Errorf("no hay bloques libres")
	}

	// Inicializa el nuevo inodo correctamente
	var newInode Structs.Inode
	initInode(&newInode) // Inicializa el inodo con valores predeterminados
	newInode.I_size = int32(size)
	newInode.I_type = [1]byte{1} // Tipo archivo
	newInode.I_block[0] = newBlockIndex

	// Escribe el nuevo inodo en el offset correcto para el nuevo inodo
	inodeOffset := int64(superblock.S_inode_start + newInodeIndex*int32(binary.Size(Structs.Inode{})))
	if err := Utilities.WriteObject(file, newInode, inodeOffset); err != nil {
		return fmt.Errorf("error al escribir el inodo del archivo: %v", err)
	}

	// Inicializa el nuevo fileblock
	var newFileblock Structs.Fileblock
	copy(newFileblock.B_content[:], content)

	// Depuración: Imprimir el contenido que se va a escribir en el bloque
	fmt.Printf("Escribiendo contenido en el bloque: %s\n", content)

	// Escribe el nuevo fileblock en el archivo
	blockOffset := int64(superblock.S_block_start + newBlockIndex*int32(binary.Size(Structs.Fileblock{})))
	if err := Utilities.WriteObject(file, newFileblock, blockOffset); err != nil {
		return fmt.Errorf("error al escribir el bloque de archivo: %v", err)
	}
	// Marca el inodo y el bloque como usados en los bitmaps
	if err := markInodeAsUsed(newInodeIndex, superblock, file); err != nil {
		return fmt.Errorf("error al marcar el inodo como usado: %v", err)
	}
	if err := markBlockAsUsed(newBlockIndex, superblock, file); err != nil {
		return fmt.Errorf("error al marcar el bloque como usado: %v", err)
	}

	// Actualiza el folderblock del inodo padre
	if err := updateParentFolderblock(fileName, parentInode, newInodeIndex, file, superblock); err != nil {
		return fmt.Errorf("error al actualizar el folderblock del inodo padre: %v", err)
	}

	// Escribir de nuevo el superbloque con las modificaciones
	if err := Utilities.WriteObject(file, superblock, partitionStart); err != nil {
		return fmt.Errorf("error al actualizar el superbloque final: %v", err)
	}

	return nil
}

func findFreeInode(superblock Structs.Superblock, file *os.File) int32 {
	for i := int32(0); i < superblock.S_inodes_count; i++ {
		var status byte
		offset := int64(superblock.S_bm_inode_start + i)
		if err := Utilities.ReadObject(file, &status, offset); err != nil {
			return -1
		}
		if status == 0 {
			return i
		}
	}
	return -1
}

// Función auxiliar para inicializar un inodo
func initInode(inode *Structs.Inode) {
	// Obtener la fecha actual y formatearla como "DD/MM/YYYY"
	currentDate := time.Now().Format("02/01/2006")

	inode.I_uid = 1
	inode.I_gid = 1
	inode.I_size = 0
	copy(inode.I_atime[:], currentDate)
	copy(inode.I_ctime[:], currentDate)
	copy(inode.I_mtime[:], currentDate)
	copy(inode.I_perm[:], "664")

	for i := int32(0); i < 15; i++ {
		inode.I_block[i] = -1
	}
}

func updateParentFolderblock(name string, parentInode int32, newInodeIndex int32, file *os.File, superblock Structs.Superblock) error {
	var inode Structs.Inode
	inodeOffset := int64(superblock.S_inode_start + parentInode*int32(binary.Size(Structs.Inode{})))
	if err := Utilities.ReadObject(file, &inode, inodeOffset); err != nil {
		return fmt.Errorf("error al leer el inodo padre: %v", err)
	}

	// Recorre los bloques del inodo padre para encontrar uno existente o asignar uno nuevo
	for i, block := range inode.I_block {
		if block == -1 {
			// Si no hay un bloque asignado, asignar uno nuevo
			newBlockIndex := findFreeBlock(superblock, file)
			if newBlockIndex == -1 {
				return fmt.Errorf("no hay bloques libres")
			}
			inode.I_block[i] = newBlockIndex

			// Inicializa el nuevo Folderblock y escríbelo
			var newFolderblock Structs.Folderblock
			newFolderblock.B_content[0].B_inodo = newInodeIndex
			copy(newFolderblock.B_content[0].B_name[:], name)

			blockOffset := int64(superblock.S_block_start + newBlockIndex*int32(binary.Size(Structs.Folderblock{})))
			if err := Utilities.WriteObject(file, newFolderblock, blockOffset); err != nil {
				return fmt.Errorf("error al escribir el nuevo folderblock: %v", err)
			}

			// Escribe el inodo actualizado en el archivo
			if err := Utilities.WriteObject(file, inode, inodeOffset); err != nil {
				return fmt.Errorf("error al actualizar el inodo padre: %v", err)
			}

			// Marca el bloque como usado en el bitmap
			if err := markBlockAsUsed(newBlockIndex, superblock, file); err != nil {
				return fmt.Errorf("error al marcar el bloque como usado: %v", err)
			}

			return nil
		}

		// Leer el folderblock existente
		var folderblock Structs.Folderblock
		blockOffset := int64(superblock.S_block_start + block*int32(binary.Size(Structs.Folderblock{})))
		if err := Utilities.ReadObject(file, &folderblock, blockOffset); err != nil {
			return fmt.Errorf("error al leer el folderblock existente: %v", err)
		}

		// Buscar un espacio vacío dentro del folderblock
		for j, content := range folderblock.B_content {
			if content.B_inodo == -1 {
				// Inserta el nuevo contenido sin sobrescribir los existentes
				folderblock.B_content[j].B_inodo = newInodeIndex
				copy(folderblock.B_content[j].B_name[:], name)
				if err := Utilities.WriteObject(file, folderblock, blockOffset); err != nil {
					return fmt.Errorf("error al actualizar el folderblock: %v", err)
				}
				return nil
			}
		}
	}

	// Si no se encontró espacio, lanza un error
	return fmt.Errorf("no hay espacio en el folderblock del inodo padre")
}

func findFreeBlock(superblock Structs.Superblock, file *os.File) int32 {
	for i := int32(0); i < superblock.S_blocks_count; i++ {
		var status byte
		offset := int64(superblock.S_bm_block_start + i)
		if err := Utilities.ReadObject(file, &status, offset); err != nil {
			return -1
		}
		if status == 0 {
			return i
		}
	}
	return -1
}

// Función auxiliar para marcar un inodo como usado
func markInodeAsUsed(inodeIndex int32, superblock Structs.Superblock, file *os.File) error {
	bitmapOffset := int64(superblock.S_bm_inode_start + inodeIndex)
	if err := Utilities.WriteObject(file, byte(1), bitmapOffset); err != nil {
		return fmt.Errorf("error al marcar el inodo en el bitmap: %v", err)
	}
	superblock.S_free_inodes_count-- // Disminuir el contador de inodos libres
	return nil
}

// Función auxiliar para marcar un bloque como usado
func markBlockAsUsed(blockIndex int32, superblock Structs.Superblock, file *os.File) error {
	bitmapOffset := int64(superblock.S_bm_block_start + blockIndex)
	if err := Utilities.WriteObject(file, byte(1), bitmapOffset); err != nil {
		return fmt.Errorf("error al marcar el bloque en el bitmap: %v", err)
	}
	superblock.S_free_blocks_count-- // Disminuir el contador de bloques libres
	return nil
}

// generateContent genera una cadena de números del 0 al 9 hasta cumplir el tamaño ingresado
func generateContent(size int) string {
	content := ""
	for len(content) < size {
		content += "0123456789"
	}
	return content[:size] // Recorta la cadena al tamaño exacto
}

// Función para obtener la partición montada
func GetMountedPartition() *MountedPartition {
	if ActSession.ActiveSession.ID == "" {
		fmt.Println("Error: No hay ninguna sesión activa. Debe hacer login primero.")
		return nil
	}

	for _, partitions := range GetMountedPartitions() {
		for _, partition := range partitions {
			if partition.ID == ActSession.ActiveSession.ID {
				if partition.Status != '1' {
					fmt.Println("Error: La partición no está montada.")
					return nil
				}
				return &partition
			}
		}
	}

	return nil
}

//////////////////////////////////////////////////////////////////////////////

// Función para montar particiones
func Mount(path string, name string) {
	file, err := Utilities.OpenFile(path)
	if err != nil {
		fmt.Println("Error: No se pudo abrir el archivo en la ruta:", path)
		return
	}
	defer file.Close()

	var TempMBR Structs.MRB
	if err := Utilities.ReadObject(file, &TempMBR, 0); err != nil {
		fmt.Println("Error: No se pudo leer el MBR desde el archivo")
		return
	}

	fmt.Printf("Buscando partición con nombre: '%s'\n", name)

	partitionFound := false
	var partition Structs.Partition
	var partitionIndex int

	// Convertir el nombre a bytes
	nameBytes := [16]byte{}
	copy(nameBytes[:], []byte(name))

	// 🔹 Buscar en particiones primarias
	for i := 0; i < 4; i++ {
		if TempMBR.Partitions[i].Type[0] == 'p' && bytes.Equal(TempMBR.Partitions[i].Name[:], nameBytes[:]) {
			partition = TempMBR.Partitions[i]
			partitionIndex = i
			partitionFound = true
			break
		}
	}

	if !partitionFound {
		fmt.Println("Error: Partición no encontrada o no es una partición primaria")
		return
	}
	// Verificar si la partición ya está montada
	if partition.Status[0] == '1' {
		fmt.Println("Error: La partición ya está montada")
		return
	}
	// 🔹 Verificar si la partición ya está montada en `mountedPartitions`
	diskID := generateDiskID(path)
	for _, p := range mountedPartitions[diskID] {
		if p.Name == name {
			fmt.Println("Error: La partición ya está montada en memoria")
			return
		}
	}

	// 📌 **Aquí corregimos la asignación de la letra**
	var letter byte
	if len(mountedPartitions) == 0 {
		letter = 'A' // Primer disco montado usa 'A'
	} else {
		// Si es un disco nuevo, asignamos la siguiente letra disponible
		if len(mountedPartitions[diskID]) == 0 {
			letter = getNextLetter()
		} else {
			letter = mountedPartitions[diskID][0].ID[len(mountedPartitions[diskID][0].ID)-1] // Usa la misma letra del disco
		}
	}

	// 🔹 Generar ID basado en carnet y número de partición
	carnet := "202202072"
	lastTwoDigits := carnet[len(carnet)-2:] // Últimos 2 dígitos
	partitionID := fmt.Sprintf("%s%d%c", lastTwoDigits, partitionIndex+1, letter)

	// Actualizar el estado de la partición a "montada" y asignar el ID generado a la partición.
	// `partition.Status[0]` se establece en '1' para indicar que la partición está montada.
	// `copy(partition.Id[:], partitionID)` asigna el ID generado a la partición.
	partition.Status[0] = '1'
	copy(partition.Id[:], partitionID)

	// Actualizamos el `TempMBR.Partitions[partitionIndex]` para reflejar los cambios en la partición.
	TempMBR.Partitions[partitionIndex] = partition

	// 🔹 Guardar en memoria
	mountedPartitions[diskID] = append(mountedPartitions[diskID], MountedPartition{
		Path:   path,
		Name:   name,
		ID:     partitionID,
		Status: '1',
	})

	// Escribir el MBR actualizado en el archivo utilizando la función `Utilities.WriteObject`.
	// Si la escritura falla, se imprime un mensaje de error.
	if err := Utilities.WriteObject(file, TempMBR, 0); err != nil {
		fmt.Println("Error: No se pudo sobrescribir el MBR en el archivo")
		return
	}
	// 🔹 Mensajes de confirmación
	fmt.Printf("Partición montada con ID: %s\n", partitionID)
	fmt.Println("MBR actualizado:")
	Structs.PrintMBR(TempMBR)
	fmt.Println("")
	//PrintMountedPartitions()
}

// 🔹 Función para obtener la siguiente letra disponible
func getNextLetter() byte {
	highestLetter := 'A'
	for _, partitions := range mountedPartitions {
		for _, p := range partitions {
			letter := p.ID[len(p.ID)-1]
			if rune(letter) > highestLetter {
				highestLetter = rune(letter)
			}
		}
	}
	return byte(highestLetter + 1)
}

func generateDiskID(path string) string {
	return strings.ToLower(path)
}

func GetPartitionByID(id string) *MountedPartition {
	for _, partitions := range mountedPartitions {
		for _, partition := range partitions {
			if partition.ID == id {
				return &partition
			}
		}
	}
	return nil
}

// Funciones para generar los reportes (cada función llamará a Graphviz)
// generateMBRReport genera un reporte del MBR y lo guarda en la ruta especificada
func GenerateMBRReport(path string, partition MountedPartition) error {
	// Crear las carpetas padre si no existen
	err := createDirectoryIfNotExists(path)
	if err != nil {
		return err
	}

	// Obtener el nombre base del archivo sin la extensión y la imagen de salida
	dotFileName, outputImage := getFileNames(path)

	// Leer el MBR desde el archivo binario correspondiente
	file, err := os.Open(partition.Path)
	if err != nil {
		return fmt.Errorf("error al abrir el archivo del disco: %v", err)
	}
	defer file.Close()

	var mbr Structs.MRB
	if err := binary.Read(file, binary.LittleEndian, &mbr); err != nil {
		return fmt.Errorf("error al leer el MBR desde el archivo: %v", err)
	}

	// Crear el contenido DOT con una tabla
	dotContent := fmt.Sprintf(`digraph G {
        node [shape=plaintext]
        tabla [label=<
            <table border="0" cellborder="1" cellspacing="0">
                <tr><td colspan="2" bgcolor="lightblue"> REPORTE MBR </td></tr>
                <tr><td bgcolor="lightgrey">mbr_tamano</td><td>%d</td></tr>
                <tr><td bgcolor="lightgrey">mrb_fecha_creacion</td><td>%s</td></tr>
                <tr><td bgcolor="lightgrey">mbr_disk_signature</td><td>%d</td></tr>
            `, mbr.MbrSize, string(mbr.CreationDate[:]), mbr.Signature)

	// Iterar sobre todas las particiones y mostrar sus datos, incluso si no están definidas
	for i, part := range mbr.Partitions {
		// Convertir los valores a caracteres o mostrar un valor predeterminado si están vacíos
		partStatus := '0'
		if part.Status[0] != 0 {
			partStatus = rune(part.Status[0])
		}

		partType := '-'
		if part.Type[0] != 0 {
			partType = rune(part.Type[0])
		}

		partFit := '-'
		if part.Fit[0] != 0 {
			partFit = rune(part.Fit[0])
		}

		partName := strings.TrimRight(string(part.Name[:]), "\x00")

		// Definir el color de fondo según el tipo de partición
		bgColor := "white"
		if partType == 'e' {
			bgColor = "lightgreen"
		} else if partType == 'p' {
			bgColor = "lightyellow"
		}

		// Agregar la partición a la tabla, mostrando valores por defecto si es necesario
		dotContent += fmt.Sprintf(`
                <tr><td colspan="2" bgcolor="%s"> PARTICIÓN %d </td></tr>
                <tr><td bgcolor="lightgrey">part_status</td><td>%c</td></tr>
                <tr><td bgcolor="lightgrey">part_type</td><td>%c</td></tr>
                <tr><td bgcolor="lightgrey">part_fit</td><td>%c</td></tr>
                <tr><td bgcolor="lightgrey">part_start</td><td>%d</td></tr>
                <tr><td bgcolor="lightgrey">part_size</td><td>%d</td></tr>
                <tr><td bgcolor="lightgrey">part_name</td><td>%s</td></tr>
            `, bgColor, i+1, partStatus, partType, partFit, part.Start, part.Size, partName)

		// Si la partición es extendida, buscar EBRs y mostrar particiones lógicas
		if partType == 'e' {
			err = showLogicalPartitions(file, part.Start, &dotContent)
			if err != nil {
				return fmt.Errorf("error al mostrar particiones lógicas: %v", err)
			}
		}
	}

	// Cerrar la tabla y el contenido DOT
	dotContent += "</table>>] }"

	// Guardar el contenido DOT en un archivo en la carpeta especificada
	dotFilePath := filepath.Join(path, dotFileName)
	fileDot, err := os.Create(dotFilePath)
	if err != nil {
		return fmt.Errorf("error al crear el archivo DOT: %v", err)
	}
	defer fileDot.Close()

	_, err = fileDot.WriteString(dotContent)
	if err != nil {
		return fmt.Errorf("error al escribir en el archivo DOT: %v", err)
	}

	// Ejecutar el comando Graphviz para generar la imagen en la misma carpeta
	outputImagePath := filepath.Join(path, outputImage)
	cmd := exec.Command("dot", "-Tpng", dotFilePath, "-o", outputImagePath)
	err = cmd.Run()
	if err != nil {
		return fmt.Errorf("error al ejecutar Graphviz: %v", err)
	}

	fmt.Println("Imagen del reporte MBR generada en:", outputImagePath)
	return nil
}

// showLogicalPartitions muestra las particiones lógicas dentro de una partición extendida
func showLogicalPartitions(file *os.File, extendedStart int32, dotContent *string) error {
	var ebr Structs.EBR
	ebrPosition := extendedStart

	for {
		// Leer el EBR en la posición actual
		err := readEBR(file, &ebr, ebrPosition)
		if err != nil {
			return fmt.Errorf("error al leer EBR: %v", err)
		}

		// Mostrar la partición lógica solo si tiene un tamaño mayor a cero
		if ebr.PartSize > 0 {
			ebrName := strings.TrimRight(string(ebr.PartName[:]), "\x00")
			*dotContent += fmt.Sprintf(`
                <tr><td colspan="2" bgcolor="lightcoral"> PARTICIÓN LÓGICA </td></tr>
                <tr><td bgcolor="lightgrey">part_fit</td><td>%c</td></tr>
                <tr><td bgcolor="lightgrey">part_start</td><td>%d</td></tr>
                <tr><td bgcolor="lightgrey">part_size</td><td>%d</td></tr>
                <tr><td bgcolor="lightgrey">part_next</td><td>%d</td></tr>
                <tr><td bgcolor="lightgrey">part_name</td><td>%s</td></tr>
            `, ebr.PartFit, ebr.PartStart, ebr.PartSize, ebr.PartNext, ebrName)
		}

		// Si no hay más particiones lógicas, detener
		if ebr.PartNext == -1 {
			break
		}

		// Ir a la siguiente partición lógica
		ebrPosition = ebr.PartNext
	}

	return nil
}

// Función para leer un EBR desde una posición específica en el archivo
func readEBR(file *os.File, ebr *Structs.EBR, position int32) error {
	// Crear un buffer para leer los datos del EBR
	buffer := make([]byte, binary.Size(*ebr))

	// Leer los bytes del EBR desde la posición especificada
	_, err := file.ReadAt(buffer, int64(position))
	if err != nil {
		return err
	}

	// Decodificar los datos del buffer al EBR utilizando LittleEndian
	err = binary.Read(strings.NewReader(string(buffer)), binary.LittleEndian, ebr)
	if err != nil {
		return err
	}

	return nil
}

func createDirectoryIfNotExists(path string) error {
	if _, err := os.Stat(path); os.IsNotExist(err) {
		return os.MkdirAll(path, os.ModePerm)
	}
	return nil
}

// Función para obtener los nombres del archivo DOT y la imagen de salida
func getFileNames(path string) (string, string) {
	baseName := filepath.Base(path)
	baseName = strings.TrimSuffix(baseName, filepath.Ext(baseName))
	dotFileName := baseName + ".dot"
	outputImage := baseName + ".png"
	return dotFileName, outputImage
}

// GenerateDiskReport genera un reporte de la estructura de particiones del disco y lo guarda en la ruta especificada
func GenerateDiskReport(path string, partition *MountedPartition) error {
	// Crear las carpetas padre si no existen
	err := createDirectoryIfNotExists(path)
	if err != nil {
		return err
	}

	// Obtener el nombre base del archivo sin la extensión y la imagen de salida
	dotFileName, outputImage := getFileNames(path)

	// Leer el MBR desde el archivo binario correspondiente
	file, err := os.Open(partition.Path)
	if err != nil {
		return fmt.Errorf("error al abrir el archivo del disco: %v", err)
	}
	defer file.Close()

	var mbr Structs.MRB
	if err := binary.Read(file, binary.LittleEndian, &mbr); err != nil {
		return fmt.Errorf("error al leer el MBR desde el archivo: %v", err)
	}

	// Crear el contenido DOT inicial con la estructura requerida
	diskName := filepath.Base(partition.Path)
	dotContent := fmt.Sprintf(`digraph G {
				node [shape=plaintext];
				
				subgraph cluster_0 {
					label="%s";
					fontsize=20;
			`, diskName)
	dotContent += `
			tabla [label=<
				<TABLE BORDER="1" CELLBORDER="1" CELLSPACING="0" COLOR="blue">
					<TR>`

	// Variables para calcular el espacio total y usado
	var usedSpace int32
	var extendedPartition *Structs.Partition
	const mbrSize int32 = 159 // Tamaño fijo de la estructura MRB

	// Añadir MBR
	dotContent += fmt.Sprintf(`<TD BGCOLOR="lightblue">MBR</TD>`)
	usedSpace += mbrSize
	// Iterar sobre todas las particiones
	for i, part := range mbr.Partitions {
		if part.Size > 0 {
			usedSpace += part.Size
			percentage := float64(part.Size) / float64(mbr.MbrSize) * 100
			partType := rune(part.Type[0])
			partName := strings.TrimRight(string(part.Name[:]), "\x00")

			if partType == 'e' {
				extendedPartition = &mbr.Partitions[i]
				dotContent += fmt.Sprintf(`<TD><TABLE BORDER="0" CELLBORDER="1" CELLSPACING="0"><TR><TD COLSPAN="5" BGCOLOR="lightgreen">Extendida %.2f%%</TD></TR><TR>`, percentage)
				err = addLogicalPartitions(file, extendedPartition.Start, extendedPartition.Size, &dotContent)
				if err != nil {
					return fmt.Errorf("error al mostrar particiones lógicas: %v", err)
				}
				dotContent += `</TR></TABLE></TD>`
			} else {
				dotContent += fmt.Sprintf(`<TD BGCOLOR="lightyellow">%s<BR/>%.2f%%</TD>`, partName, percentage)
			}
		}
	}

	// Calcular y mostrar el espacio libre al final
	freeSpace := mbr.MbrSize - usedSpace
	if freeSpace > 0 {
		freePercentage := float64(freeSpace) / float64(mbr.MbrSize) * 100
		dotContent += fmt.Sprintf(`<TD BGCOLOR="lightgray">Libre<BR/>%.2f%%</TD>`, freePercentage)
	}

	// Cerrar la tabla y el contenido DOT
	dotContent += `
					</TR>
				</TABLE>
			>];
		}
	}` // Guardar el contenido DOT en un archivo en la carpeta especificada
	dotFilePath := filepath.Join(path, dotFileName)
	fileDot, err := os.Create(dotFilePath)
	if err != nil {
		return fmt.Errorf("error al crear el archivo DOT: %v", err)
	}
	defer fileDot.Close()

	_, err = fileDot.WriteString(dotContent)
	if err != nil {
		return fmt.Errorf("error al escribir en el archivo DOT: %v", err)
	}

	// Ejecutar el comando Graphviz para generar la imagen en la misma carpeta
	outputImagePath := filepath.Join(path, outputImage)
	cmd := exec.Command("dot", "-Tpng", dotFilePath, "-o", outputImagePath)
	err = cmd.Run()
	if err != nil {
		return fmt.Errorf("error al ejecutar Graphviz: %v", err)
	}

	fmt.Println("Imagen del reporte de disco generada en:", outputImagePath)
	return nil
}

func addLogicalPartitions(file *os.File, extendedStart int32, extendedSize int32, dotContent *string) error {
	var ebr Structs.EBR
	ebrPosition := extendedStart
	remainingSize := extendedSize

	for {
		// Leer el EBR en la posición actual
		err := readEBR(file, &ebr, ebrPosition)
		if err != nil {
			return fmt.Errorf("error al leer EBR: %v", err)
		}

		// Mostrar EBR
		*dotContent += `<TD BGCOLOR="lightblue">EBR</TD>`

		// Mostrar la partición lógica si tiene un tamaño mayor a cero
		if ebr.PartSize > 0 {
			ebrName := strings.TrimRight(string(ebr.PartName[:]), "\x00")
			percentage := float64(ebr.PartSize) / float64(extendedSize) * 100
			*dotContent += fmt.Sprintf(`<TD BGCOLOR="lightcoral">%s<BR/>%.2f%%</TD>`, ebrName, percentage)
			remainingSize -= ebr.PartSize
		}

		// Si no hay más particiones lógicas, mostrar el espacio libre restante y detener
		if ebr.PartNext == -1 {
			if remainingSize > 0 {
				freePercentage := float64(remainingSize) / float64(extendedSize) * 100
				*dotContent += fmt.Sprintf(`<TD BGCOLOR="lightgray">Libre<BR/>%.2f%%</TD>`, freePercentage)
			}
			break
		}

		// Calcular y mostrar el espacio libre entre particiones lógicas
		freeSpace := ebr.PartNext - (ebrPosition + int32(unsafe.Sizeof(ebr)) + ebr.PartSize)
		if freeSpace > 0 {
			freePercentage := float64(freeSpace) / float64(extendedSize) * 100
			*dotContent += fmt.Sprintf(`<TD BGCOLOR="lightgray">Libre<BR/>%.2f%%</TD>`, freePercentage)
		}

		// Ir a la siguiente partición lógica
		ebrPosition = ebr.PartNext
	}

	return nil
}

// GenerateInodeReport genera un reporte visual de los inodos y lo guarda en la ruta especificada
func GenerateInodeReport(path string, partition *MountedPartition) error {
	// Crear las carpetas padre si no existen
	if err := createDirectoryIfNotExists(path); err != nil {
		return fmt.Errorf("error al crear directorios: %v", err)
	}

	// Obtener el nombre base del archivo sin la extensión y la imagen de salida
	dotFileName, outputImage := getFileNames(path)

	// Abrir el archivo binario del disco desde la partición montada
	file, err := os.Open(partition.Path)
	if err != nil {
		return fmt.Errorf("error al abrir el archivo del disco: %v", err)
	}
	defer file.Close()

	// Leer el Superblock para obtener la información de los inodos
	var superblock Structs.Superblock
	superblockOffset := int64(binary.Size(Structs.MRB{})) // Ajusta según la posición real del Superblock
	if err := Utilities.ReadObject(file, &superblock, superblockOffset); err != nil {
		return fmt.Errorf("error al leer el Superblock: %v", err)
	}

	// Iniciar el contenido DOT con configuraciones de color
	dotContent := `digraph G {
		node [shape=plaintext];
		rankdir=LR; // Layout de izquierda a derecha
	`

	// Iterar sobre cada inodo y generar su representación en Graphviz
	for i := int32(0); i < superblock.S_inodes_count; i++ {
		var inode Structs.Inode
		inodeOffset := superblock.S_inode_start + i*superblock.S_inode_size
		if err := Utilities.ReadObject(file, &inode, int64(inodeOffset)); err != nil {
			return fmt.Errorf("error al leer inodo %d: %v", i, err)
		}

		// Verificar si el inodo está vacío (sin uso)
		if isEmptyInode(inode) {
			continue // Omitir inodos vacíos
		}

		// Agregar representación del inodo al contenido DOT
		dotContent += formatInodeToDot(i, inode)

		// Conectar con el siguiente inodo si no es el último
		if i < superblock.S_inodes_count-1 {
			dotContent += fmt.Sprintf("inode%d -> inode%d;\n", i, i+1)
		}
	}

	// Cerrar el contenido DOT
	dotContent += "}"

	// Crear el archivo DOT
	dotFilePath := filepath.Join(path, dotFileName)
	if err := os.WriteFile(dotFilePath, []byte(dotContent), 0644); err != nil {
		return fmt.Errorf("error al crear o escribir en el archivo DOT: %v", err)
	}

	// Ejecutar el comando Graphviz para generar la imagen en la misma carpeta
	outputImagePath := filepath.Join(path, outputImage)
	if err := exec.Command("dot", "-Tpng", dotFilePath, "-o", outputImagePath).Run(); err != nil {
		return fmt.Errorf("error al ejecutar Graphviz: %v", err)
	}

	fmt.Println("Imagen del reporte de inodos generada en:", outputImagePath)
	return nil
}

// formatInodeToDot genera la representación en formato DOT de un inodo dado
func formatInodeToDot(index int32, inode Structs.Inode) string {
	// Convertir tiempos a string
	atime := cleanDateString(string(inode.I_atime[:]))
	ctime := cleanDateString(string(inode.I_ctime[:]))
	mtime := cleanDateString(string(inode.I_mtime[:]))

	// Definir el contenido DOT para el inodo actual con colores
	var typeStr string
	switch inode.I_type[0] {
	case '\x00':
		typeStr = "Directorio"
	case '\x01':
		typeStr = "Archivo"
	default:
		typeStr = "Desconocido" // Para cualquier otro valor inesperado
	}

	// Definir el contenido DOT para el inodo actual con el tipo corregido
	content := fmt.Sprintf(`inode%d [label=<
		<table border="0" cellborder="1" cellspacing="0">
			<tr><td colspan="2" bgcolor="#B0C4DE"><b>REPORTE INODO %d</b></td></tr>
			<tr><td bgcolor="#F5F5F5"><b>UID</b></td><td bgcolor="#FFFFFF">%d</td></tr>
			<tr><td bgcolor="#F5F5F5"><b>GID</b></td><td bgcolor="#FFFFFF">%d</td></tr>
			<tr><td bgcolor="#F5F5F5"><b>Size</b></td><td bgcolor="#FFFFFF">%d</td></tr>
			<tr><td bgcolor="#F5F5F5"><b>Atime</b></td><td bgcolor="#FFFFFF">%s</td></tr>
			<tr><td bgcolor="#F5F5F5"><b>Ctime</b></td><td bgcolor="#FFFFFF">%s</td></tr>
			<tr><td bgcolor="#F5F5F5"><b>Mtime</b></td><td bgcolor="#FFFFFF">%s</td></tr>
			<tr><td bgcolor="#F5F5F5"><b>Type</b></td><td bgcolor="#FFFFFF">%s</td></tr>
			<tr><td bgcolor="#F5F5F5"><b>Perm</b></td><td bgcolor="#FFFFFF">%s</td></tr>
			<tr><td colspan="2" bgcolor="#D3D3D3"><b>BLOQUES DIRECTOS</b></td></tr>
		`, index, index, inode.I_uid, inode.I_gid, inode.I_size, atime, ctime, mtime, typeStr, string(inode.I_perm[:]))

	// Agregar los bloques directos a la tabla
	for j, block := range inode.I_block[:12] {
		color := "#FFFFFF" // Color de fondo para bloques asignados
		if block == -1 {
			color = "#FFCCCB" // Resaltar bloques no asignados en rojo claro
		}
		content += fmt.Sprintf("<tr><td bgcolor=\"#F5F5F5\">Bloque %d</td><td bgcolor=\"%s\">%d</td></tr>", j+1, color, block)
	}

	// Agregar bloques indirectos, doble y triple con colores distintos
	content += fmt.Sprintf(`
		<tr><td colspan="2" bgcolor="#D3D3D3"><b>BLOQUE INDIRECTO</b></td></tr>
		<tr><td bgcolor="#F5F5F5">13</td><td bgcolor="#FFFFFF">%d</td></tr>
		<tr><td colspan="2" bgcolor="#D3D3D3"><b>BLOQUE INDIRECTO DOBLE</b></td></tr>
		<tr><td bgcolor="#F5F5F5">14</td><td bgcolor="#FFFFFF">%d</td></tr>
		<tr><td colspan="2" bgcolor="#D3D3D3"><b>BLOQUE INDIRECTO TRIPLE</b></td></tr>
		<tr><td bgcolor="#F5F5F5">15</td><td bgcolor="#FFFFFF">%d</td></tr>
		</table>>];
	`, inode.I_block[12], inode.I_block[13], inode.I_block[14])

	return content
}

// isEmptyInode verifica si un inodo está vacío o no contiene información útil
func isEmptyInode(inode Structs.Inode) bool {
	// Comprobar si el inodo está vacío basado en los valores típicos que indican inactividad
	if inode.I_uid == 0 && inode.I_gid == 0 && inode.I_size == 0 {
		// Comprobar si todos los bloques son -1 (no asignados)
		for _, block := range inode.I_block {
			if block != -1 {
				return false // No está vacío, tiene al menos un bloque asignado
			}
		}
		return true // Todos los bloques son -1 y los valores principales son cero
	}
	return false // El inodo tiene información relevante
}

// cleanDateString elimina caracteres no deseados de las cadenas de fechas
func cleanDateString(date string) string {
	// Remueve caracteres nulos y espacios en blanco innecesarios
	return strings.TrimRight(date, "\x00 ")
}

// GenerateBlockReport genera un reporte visual de los bloques y lo guarda en la ruta especificada
func GenerateBlockReport(path string, partition *MountedPartition) error {
	// Crear las carpetas padre si no existen
	if err := createDirectoryIfNotExists(path); err != nil {
		return fmt.Errorf("Error al crear directorios: %v", err)
	}

	// Obtener el nombre base del archivo sin la extensión y la imagen de salida
	dotFileName, outputImage := getFileNames(path)

	// Abrir el archivo binario del disco desde la partición montada
	file, err := os.Open(partition.Path)
	if err != nil {
		return fmt.Errorf("Error al abrir el archivo del disco: %v", err)
	}
	defer file.Close()

	// Leer el Superblock para obtener la información de los bloques
	var superblock Structs.Superblock
	superblockOffset := int64(binary.Size(Structs.MRB{})) // Ajusta según la posición real del Superblock
	if err := Utilities.ReadObject(file, &superblock, superblockOffset); err != nil {
		return fmt.Errorf("Error al leer el Superblock: %v", err)
	}

	// Iniciar el contenido DOT con configuraciones de color y orden horizontal
	dotContent := `digraph G {
		rankdir=LR; // Layout de izquierda a derecha
		node [shape=plaintext];
	`

	// Variable para almacenar el nombre del nodo anterior para conectar los bloques
	var previousBlock string

	// Iterar sobre cada bloque y generar su representación en Graphviz
	for i := int32(0); i < superblock.S_blocks_count; i++ {
		var fileBlock Structs.Fileblock
		blockOffset := superblock.S_block_start + i*superblock.S_block_size
		if err := Utilities.ReadObject(file, &fileBlock, int64(blockOffset)); err != nil {
			return fmt.Errorf("Error al leer bloque %d: %v", i, err)
		}

		// Limpiar el contenido del bloque para eliminar caracteres no imprimibles
		blockContent := cleanStringb(string(fileBlock.B_content[:]))
		if blockContent != "" {
			// Agregar representación del bloque al contenido DOT
			blockName := fmt.Sprintf("block%d", i)
			dotContent += formatBlockToDot(i, blockContent)

			// Conectar el bloque anterior con el actual
			if previousBlock != "" {
				dotContent += fmt.Sprintf("%s -> %s;\n", previousBlock, blockName)
			}

			// Actualizar el nombre del nodo anterior
			previousBlock = blockName
		}
	}

	// Cerrar el contenido DOT
	dotContent += "}"

	// Crear el archivo DOT
	dotFilePath := filepath.Join(path, dotFileName)
	if err := os.WriteFile(dotFilePath, []byte(dotContent), 0644); err != nil {
		return fmt.Errorf("Error al crear o escribir en el archivo DOT: %v", err)
	}

	// Ejecutar el comando Graphviz para generar la imagen en la misma carpeta
	outputImagePath := filepath.Join(path, outputImage)
	if err := exec.Command("dot", "-Tpng", dotFilePath, "-o", outputImagePath).Run(); err != nil {
		return fmt.Errorf("Error al ejecutar Graphviz: %v", err)
	}

	fmt.Println("Imagen del reporte de bloques generada en:", outputImagePath)
	return nil
}

// formatBlockToDot genera la representación en formato DOT de un bloque dado
func formatBlockToDot(index int32, content string) string {
	// Definir el contenido DOT para el bloque actual con colores y separarlo horizontalmente
	blockDot := fmt.Sprintf(`block%d [label=<
		<table border="1" cellborder="1" cellspacing="0">
			<tr><td colspan="2" bgcolor="#B0C4DE"><b>REPORTE BLOQUE %d</b></td></tr>
			<tr><td bgcolor="#F5F5F5"><b>Contenido</b></td><td bgcolor="#FFFFFF">%s</td></tr>
		</table>>];
	`, index, index, content)

	return blockDot
}

// cleanString elimina o reemplaza caracteres no imprimibles de una cadena
func cleanStringb(s string) string {
	// Reemplaza o elimina caracteres no imprimibles
	cleaned := strings.Map(func(r rune) rune {
		if r < 32 || r > 126 { // Rango de caracteres imprimibles ASCII estándar
			return -1 // -1 indica que el carácter debe eliminarse
		}
		return r
	}, s)
	return cleaned
}

func GenerateBMInodeReport(path string, partition *MountedPartition) error {
	// Asegúrate de que la partición montada no sea nula
	if partition == nil {
		return fmt.Errorf("Error: La partición montada proporcionada es nula")
	}

	// Abrir el archivo de disco para leer el Superblock
	file, err := Utilities.OpenFile(partition.Path)
	if err != nil {
		return fmt.Errorf("Error al abrir el archivo de disco: %v", err)
	}
	defer file.Close()

	// Leer el MBR para ubicar la partición
	var TempMBR Structs.MRB
	if err := Utilities.ReadObject(file, &TempMBR, 0); err != nil {
		return fmt.Errorf("Error al leer el MBR del archivo: %v", err)
	}

	// Buscar la partición correspondiente dentro del MBR
	var partitionData Structs.Partition
	partitionFound := false
	for i := 0; i < 4; i++ {
		if string(TempMBR.Partitions[i].Id[:]) == partition.ID {
			partitionData = TempMBR.Partitions[i]
			partitionFound = true
			break
		}
	}

	// Si no se encuentra la partición dentro del MBR, retornar un error
	if !partitionFound {
		return fmt.Errorf("Error: Partición no encontrada dentro del MBR")
	}

	// Leer el Superblock de la partición
	var superblock Structs.Superblock
	superblockOffset := int64(partitionData.Start)
	if err := Utilities.ReadObject(file, &superblock, superblockOffset); err != nil {
		return fmt.Errorf("Error al leer el Superblock desde el archivo: %v", err)
	}

	dir := filepath.Dir(path)
	if err := createDirectoryIfNotExists(dir); err != nil {
		fmt.Println("Error al crear directorios:", err)
		return fmt.Errorf("Error al crear directorios: %v", err)
	}

	// Calcular el número total de inodos
	totalInodes := superblock.S_inodes_count + superblock.S_free_inodes_count

	// Obtener el contenido del bitmap de inodos
	var bitmapContent strings.Builder

	for i := int32(0); i < totalInodes; i++ {
		// Establecer el puntero
		_, err := file.Seek(int64(superblock.S_bm_inode_start+i), 0)
		if err != nil {
			fmt.Println("error al establecer el puntero en el archivo:", err)
			return fmt.Errorf("error al establecer el puntero en el archivo: %v", err)
		}

		// Leer un byte (carácter '0' o '1')
		char := make([]byte, 1)
		_, err = file.Read(char)
		if err != nil {
			fmt.Println("error al leer el byte del archivo:", err)
			return fmt.Errorf("error al leer el byte del archivo: %v", err)
		}

		// Agregar el carácter al contenido del bitmap
		//bitmapContent.WriteByte(char[0])
		if char[0] == 1 {
			bitmapContent.WriteByte('1')
		} else {
			bitmapContent.WriteByte('0')
		}
		// Agregar un carácter de nueva línea cada 20 caracteres (20 inodos)
		if (i+1)%20 == 0 {
			bitmapContent.WriteString("\n")
		}
	}

	// Crear el archivo TXT
	txtFile, err := os.Create(path)
	if err != nil {
		fmt.Printf("error al crear el archivo TXT: %v", err)
		return fmt.Errorf("error al crear el archivo TXT: %v", err)
	}
	defer txtFile.Close()

	// Escribir el contenido del bitmap en el archivo TXT
	_, err = txtFile.WriteString(bitmapContent.String())
	if err != nil {
		fmt.Printf("error al escribir en el archivo TXT: %v", err)
		return fmt.Errorf("error al escribir en el archivo TXT: %v", err)
	}
	fmt.Println("Archivo del reporte del bitmap de inodos generado en:", path)
	return nil
}

func GenerateBMBlockReport(path string, partition *MountedPartition) error {
	// Asegúrate de que la partición montada no sea nula
	if partition == nil {
		return fmt.Errorf("Error: La partición montada proporcionada es nula")
	}

	// Abrir el archivo de disco para leer el Superblock
	file, err := Utilities.OpenFile(partition.Path)
	if err != nil {
		return fmt.Errorf("Error al abrir el archivo de disco: %v", err)
	}
	defer file.Close()

	// Leer el MBR para ubicar la partición
	var TempMBR Structs.MRB
	if err := Utilities.ReadObject(file, &TempMBR, 0); err != nil {
		return fmt.Errorf("Error al leer el MBR del archivo: %v", err)
	}

	// Buscar la partición correspondiente dentro del MBR
	var partitionData Structs.Partition
	partitionFound := false
	for i := 0; i < 4; i++ {
		if string(TempMBR.Partitions[i].Id[:]) == partition.ID {
			partitionData = TempMBR.Partitions[i]
			partitionFound = true
			break
		}
	}

	// Si no se encuentra la partición dentro del MBR, retornar un error
	if !partitionFound {
		return fmt.Errorf("Error: Partición no encontrada dentro del MBR")
	}

	// Leer el Superblock de la partición
	var superblock Structs.Superblock
	superblockOffset := int64(partitionData.Start)
	if err := Utilities.ReadObject(file, &superblock, superblockOffset); err != nil {
		return fmt.Errorf("Error al leer el Superblock desde el archivo: %v", err)
	}

	dir := filepath.Dir(path)
	if err := createDirectoryIfNotExists(dir); err != nil {
		return fmt.Errorf("Error al crear directorios: %v", err)
	}

	// Calcular el número total de bloques
	totalBlocks := superblock.S_blocks_count + superblock.S_free_blocks_count

	// Obtener el contenido del bitmap de bloques
	var bitmapContent strings.Builder

	for i := int32(0); i < totalBlocks; i++ {
		// Establecer el puntero en el inicio del bitmap de bloques
		_, err := file.Seek(int64(superblock.S_bm_block_start+i), 0)
		if err != nil {
			return fmt.Errorf("error al establecer el puntero en el archivo: %v", err)
		}

		// Leer un byte (carácter '0' o '1')
		char := make([]byte, 1)
		_, err = file.Read(char)
		if err != nil {
			return fmt.Errorf("error al leer el byte del archivo: %v", err)
		}

		// Agregar el carácter al contenido del bitmap
		//bitmapContent.WriteByte(char[0])
		if char[0] == 1 {
			bitmapContent.WriteByte('1')
		} else {
			bitmapContent.WriteByte('0')
		}
		// Agregar un carácter de nueva línea cada 20 caracteres (20 bloques)
		if (i+1)%20 == 0 {
			bitmapContent.WriteString("\n")
		}
	}

	// Crear el archivo TXT
	txtFile, err := os.Create(path)
	if err != nil {
		return fmt.Errorf("error al crear el archivo TXT: %v", err)
	}
	defer txtFile.Close()

	// Escribir el contenido del bitmap en el archivo TXT
	_, err = txtFile.WriteString(bitmapContent.String())
	if err != nil {
		return fmt.Errorf("error al escribir en el archivo TXT: %v", err)
	}
	fmt.Println("Archivo del reporte del bitmap de bloques generado en:", path)
	return nil
}

// GenerateSuperblockReport genera un reporte del Superbloque y lo guarda en la ruta especificada
func GenerateSuperblockReport(path string, partition *MountedPartition) error {
	// Asegúrate de que la partición montada no sea nula
	if partition == nil {
		return fmt.Errorf("Error: La partición montada proporcionada es nula")
	}

	// Abrir el archivo de disco para leer el Superblock
	file, err := Utilities.OpenFile(partition.Path)
	if err != nil {
		return fmt.Errorf("Error al abrir el archivo de disco: %v", err)
	}
	defer file.Close()

	// Leer el MBR para ubicar la partición
	var TempMBR Structs.MRB
	if err := Utilities.ReadObject(file, &TempMBR, 0); err != nil {
		return fmt.Errorf("Error al leer el MBR del archivo: %v", err)
	}

	// Buscar la partición correspondiente dentro del MBR
	var partitionData Structs.Partition
	partitionFound := false
	for i := 0; i < 4; i++ {
		if string(TempMBR.Partitions[i].Id[:]) == partition.ID {
			partitionData = TempMBR.Partitions[i]
			partitionFound = true
			break
		}
	}

	// Si no se encuentra la partición dentro del MBR, retornar un error
	if !partitionFound {
		return fmt.Errorf("Error: Partición no encontrada dentro del MBR")
	}

	// Leer el Superblock de la partición
	var superblock Structs.Superblock
	superblockOffset := int64(partitionData.Start)
	if err := Utilities.ReadObject(file, &superblock, superblockOffset); err != nil {
		return fmt.Errorf("Error al leer el Superblock desde el archivo: %v", err)
	}

	// Crear las carpetas padre si no existen
	if err := createDirectoryIfNotExists(path); err != nil {
		return fmt.Errorf("Error al crear directorios: %v", err)
	}

	// Obtener el nombre base del archivo sin la extensión y la imagen de salida
	dotFileName, outputImage := getFileNames(path)

	// Iniciar el contenido DOT para el Superbloque
	dotContent := `digraph G {
		node [shape=plaintext];
		tabla [label=<
			<table border="1" cellborder="1" cellspacing="0" cellpadding="10">
				<tr><td colspan="2" bgcolor="darkgreen"><font color="white">Reporte de SUPERBLOQUE</font></td></tr>
				<tr><td bgcolor="lightgreen">sb_nombre_hd</td><td>` + partition.Path + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_filesystem_type</td><td>` + fmt.Sprintf("%d", superblock.S_filesystem_type) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_inodes_count</td><td>` + fmt.Sprintf("%d", superblock.S_inodes_count) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_blocks_count</td><td>` + fmt.Sprintf("%d", superblock.S_blocks_count) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_free_blocks_count</td><td>` + fmt.Sprintf("%d", superblock.S_free_blocks_count) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_free_inodes_count</td><td>` + fmt.Sprintf("%d", superblock.S_free_inodes_count) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_mtime</td><td>` + cleanDateString(string(superblock.S_mtime[:])) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_umtime</td><td>` + cleanDateString(string(superblock.S_umtime[:])) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_mnt_count</td><td>` + fmt.Sprintf("%d", superblock.S_mnt_count) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_magic</td><td>` + fmt.Sprintf("0x%X", superblock.S_magic) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_inode_size</td><td>` + fmt.Sprintf("%d", superblock.S_inode_size) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_block_size</td><td>` + fmt.Sprintf("%d", superblock.S_block_size) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_fist_ino</td><td>` + fmt.Sprintf("%d", superblock.S_fist_ino) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_first_blo</td><td>` + fmt.Sprintf("%d", superblock.S_first_blo) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_bm_inode_start</td><td>` + fmt.Sprintf("%d", superblock.S_bm_inode_start) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_bm_block_start</td><td>` + fmt.Sprintf("%d", superblock.S_bm_block_start) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_inode_start</td><td>` + fmt.Sprintf("%d", superblock.S_inode_start) + `</td></tr>
				<tr><td bgcolor="lightgreen">sb_block_start</td><td>` + fmt.Sprintf("%d", superblock.S_block_start) + `</td></tr>
			</table>>];
	}`

	// Crear el archivo DOT
	dotFilePath := filepath.Join(path, dotFileName)
	if err := os.WriteFile(dotFilePath, []byte(dotContent), 0644); err != nil {
		return fmt.Errorf("Error al crear o escribir en el archivo DOT: %v", err)
	}

	// Ejecutar el comando Graphviz para generar la imagen en la misma carpeta
	outputImagePath := filepath.Join(path, outputImage)
	if err := exec.Command("dot", "-Tpng", dotFilePath, "-o", outputImagePath).Run(); err != nil {
		return fmt.Errorf("Error al ejecutar Graphviz: %v", err)
	}

	fmt.Println("Imagen del reporte del Superbloque generada en:", outputImagePath)
	return nil
}

func GenerateLsReport(path string, partition MountedPartition, pathFileLs string) {
}

// GetMountedPartitionSuperblock busca una partición montada por su ID y obtiene su Superblock.
func GetMountedPartitionSuperblock(id string) (*Structs.Superblock, *MountedPartition, string, error) {
	// Buscar la partición montada con el ID proporcionado
	var mountedPartition *MountedPartition
	var partitionFound bool

	// Buscar en el mapa de particiones montadas
	for _, partitions := range mountedPartitions {
		for _, partition := range partitions {
			if partition.ID == id {
				mountedPartition = &partition
				partitionFound = true
				break
			}
		}
		if partitionFound {
			break
		}
	}

	// Si no se encontró la partición, retornar un error
	if !partitionFound {
		return nil, nil, "", fmt.Errorf("Error: Partición con ID %s no encontrada", id)
	}

	// Abrir el archivo de disco para leer el Superblock
	file, err := Utilities.OpenFile(mountedPartition.Path)
	if err != nil {
		return nil, nil, "", fmt.Errorf("Error al abrir el archivo de disco: %v", err)
	}
	defer file.Close()

	// Leer el MBR para ubicar la partición
	var TempMBR Structs.MRB
	if err := Utilities.ReadObject(file, &TempMBR, 0); err != nil {
		return nil, nil, "", fmt.Errorf("Error al leer el MBR del archivo: %v", err)
	}

	// Buscar la partición correspondiente dentro del MBR
	var partition Structs.Partition
	partitionFound = false
	for i := 0; i < 4; i++ {
		if string(TempMBR.Partitions[i].Id[:]) == mountedPartition.ID {
			partition = TempMBR.Partitions[i]
			partitionFound = true
			break
		}
	}

	// Si no se encuentra la partición dentro del MBR, retornar un error
	if !partitionFound {
		return nil, nil, "", fmt.Errorf("Error: Partición no encontrada dentro del MBR")
	}

	// Leer el Superblock de la partición
	var superblock Structs.Superblock
	superblockOffset := int64(partition.Start)
	if err := Utilities.ReadObject(file, &superblock, superblockOffset); err != nil {
		return nil, nil, "", fmt.Errorf("Error al leer el Superblock desde el archivo: %v", err)
	}

	// Retornar el Superblock, la partición montada y la ruta del archivo
	return &superblock, mountedPartition, mountedPartition.Path, nil
}
