package Rep

import (
	"MIA_P1/backend/Management"
	"MIA_P1/backend/User"
	"fmt"
	"os"
	"path/filepath"
)

func GenerateFileReport(path string, partition *Management.MountedPartition, pathFileLs string) error {

	if partition == nil {
		return fmt.Errorf("Error: No hay partición montada")
	}

	// Buscar el archivo dentro del sistema EXT2
	fileContent, err := User.ReadMultipleFiles([]string{pathFileLs})
	if err != nil {
		return fmt.Errorf("Error al leer el archivo en el sistema de archivos EXT2: %v", err)
	}

	dir := filepath.Dir(path)
	if err := createDirectoryIfNotExists(dir); err != nil {
		return fmt.Errorf("Error al crear directorios: %v", err)
	}

	// Crear archivo de salida .txt
	txtFile, err := os.Create(path)
	if err != nil {
		return fmt.Errorf("Error al crear el archivo de salida: %v", err)
	}
	defer txtFile.Close()

	// Escribir contenido del archivo leído
	_, err = txtFile.WriteString(fileContent)
	if err != nil {
		return fmt.Errorf("Error al escribir en el archivo de salida: %v", err)
	}

	fmt.Println("Reporte FILE generado en:", path)
	return nil
}

func createDirectoryIfNotExists(path string) error {
	if _, err := os.Stat(path); os.IsNotExist(err) {
		return os.MkdirAll(path, os.ModePerm)
	}
	return nil
}
